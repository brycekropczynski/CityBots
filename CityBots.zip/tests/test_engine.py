import asyncio
import time
from datetime import date, datetime, timedelta, timezone
from types import SimpleNamespace as NS

from fastapi.testclient import TestClient

from citybots.bots import build_bots
from citybots.data.alpaca_feed import AlpacaFeed
from citybots.data.replay_feed import ReplayFeed, previous_month
from citybots.data.synthetic import synthetic_bars
from citybots.engine import Engine
from citybots.execution.sim_broker import SimBroker
from citybots.hub import Hub
from citybots.server import create_app
from citybots.storage import Store

TICKERS = ("AAA", "BBB", "CCC")
START, END = date(2026, 9, 7), date(2026, 10, 9)
WARM_START, WARM_END = date(2026, 7, 6), date(2026, 9, 6)


def run_replay(seed=7):
    bars = synthetic_bars(TICKERS, START, END, seed)
    warm = synthetic_bars(TICKERS, WARM_START, WARM_END, seed + 1)
    store = Store(":memory:")
    feed = ReplayFeed(lambda: bars, speed=0, load_warmup=lambda: warm)
    engine = Engine(build_bots(seed=seed), feed, SimBroker(), store, Hub(), "r1", "replay")
    asyncio.run(engine.run())
    return engine, store


def test_replay_logs_every_required_trade_field():
    engine, store = run_replay()
    assert engine.hub.status["state"] == "finished"
    rows = store.trades("r1")
    assert rows and {r["bot"] for r in rows} == {b.name for b in engine.bots}
    for r in rows[:50]:
        assert r["bot"] and r["ticker"] in TICKERS and r["side"] in ("buy", "sell")
        assert r["price"] > 0 and r["qty"] > 0 and datetime.fromisoformat(r["time"])


def test_replay_is_repeatable():
    first, _ = run_replay()
    second, _ = run_replay()
    assert first.leaderboard() == second.leaderboard()


def test_bots_stay_inside_risk_limits_during_replay():
    engine, store = run_replay()
    for bot in engine.bots:
        peak_equity = 10_000 * 1.5
        for r in store.trades("r1", bot.name):
            if r["side"] == "buy":
                # Sized off the prior close, so allow a little room for the next open.
                assert r["qty"] * r["price"] <= 0.10 * peak_equity * 1.02
        assert bot.cash > -50


def test_ledgers_rebuild_from_trade_log():
    engine, store = run_replay()
    for bot in engine.bots:
        rebuilt = type(bot)(bot.risk)
        rebuilt.restore(store.trades("r1", bot.name))
        assert abs(rebuilt.cash - bot.cash) < 1e-6
        assert set(rebuilt.positions) == set(bot.positions)


def test_previous_month_handles_year_boundary():
    assert previous_month(date(2026, 11, 3)) == (date(2026, 10, 1), date(2026, 10, 31))
    assert previous_month(date(2027, 1, 15)) == (date(2026, 12, 1), date(2026, 12, 31))


def test_replay_pacing_matches_requested_speed():
    bars = synthetic_bars(("AAA",), START, START, 1)[:5]

    async def go():
        async for _ in ReplayFeed(lambda: bars, speed=3000).events():  # 0.02s per bar
            pass

    begin = time.monotonic()
    asyncio.run(go())
    assert 0.09 <= time.monotonic() - begin < 0.5


def test_live_feed_reports_new_minute_bar_only_once():
    ts = datetime(2026, 10, 5, 14, 0, tzinfo=timezone.utc)
    minute = NS(timestamp=ts, open=1, high=2, low=1, close=2, volume=10)
    snap = {"AAA": NS(latest_trade=NS(price=2.5), minute_bar=minute)}
    feed = AlpacaFeed(["AAA"], None, None)
    first, second = feed._to_event(snap), feed._to_event(snap)
    assert len(first.closed_bars) == 1 and second.closed_bars == []
    assert second.prices == {"AAA": 2.5}


def test_warmup_history_never_creates_trades():
    warm = synthetic_bars(TICKERS, WARM_START, WARM_END, 1)
    store = Store(":memory:")
    feed = ReplayFeed(lambda: synthetic_bars(TICKERS, START, START, 1), speed=0, load_warmup=lambda: warm)
    engine = Engine(build_bots(), feed, SimBroker(), store, Hub(), "r1", "replay")
    asyncio.run(engine.run())
    assert all(r["time"] >= START.isoformat() for r in store.trades("r1"))
    assert len(engine.bots[1].candles["AAA"]) >= 30


def test_live_feed_final_poll_after_close_is_flagged_closing():
    now = datetime(2026, 10, 5, 20, 0, tzinfo=timezone.utc)
    states = iter([True, False])
    ts = now - timedelta(minutes=1)
    minute = NS(timestamp=ts, open=1, high=2, low=1, close=2, volume=10)
    snap = {"AAA": NS(latest_trade=NS(price=2.0), minute_bar=minute)}
    trading = NS(get_clock=lambda: NS(is_open=next(states), timestamp=now, next_open=now + timedelta(hours=17)))
    data = NS(get_stock_snapshot=lambda request: snap)

    async def no_sleep(_):
        return None

    feed = AlpacaFeed(["AAA"], trading, data, sleep=no_sleep)

    async def go():
        seen = []
        async for event in feed.events():
            seen.append(event.closing)
            if len(seen) == 2:
                break
        return seen

    assert asyncio.run(go()) == [False, True]


def test_live_feed_waits_while_market_is_closed():
    now = datetime(2026, 10, 5, 2, 0, tzinfo=timezone.utc)
    clock = NS(is_open=False, timestamp=now, next_open=now + timedelta(hours=11))
    feed = AlpacaFeed(["AAA"], NS(get_clock=lambda: clock), None)
    statuses, waits = [], []
    feed.on_status = lambda **kw: statuses.append(kw)

    async def stop_after_first(s):
        waits.append(s)
        raise asyncio.CancelledError

    feed.sleep = stop_after_first

    async def go():
        async for _ in feed.events():
            raise AssertionError("no events while closed")

    try:
        asyncio.run(go())
    except asyncio.CancelledError:
        pass
    assert statuses[0]["state"] == "waiting" and waits == [60.0]


def test_websocket_streams_snapshot_then_updates():
    hub = Hub()
    hub.publish_equity([{"name": "Momentum", "return_pct": 1.0}], sim_time="t")
    with TestClient(create_app(hub)) as client:
        with client.websocket_connect("/ws", headers={"host": "testserver"}) as ws:
            snapshot = ws.receive_json()
            assert snapshot["type"] == "snapshot" and snapshot["bots"][0]["name"] == "Momentum"
            ws.portal.call(hub.publish_trade, {"bot": "Momentum", "side": "buy"})  # on the app's event loop
            assert ws.receive_json()["type"] == "trade"
        assert client.get("/").status_code == 200
        assert client.get("/api/state").json()["status"]["sim_time"] == "t"


def test_websocket_rejects_other_sites():
    from starlette.websockets import WebSocketDisconnect
    import pytest

    with TestClient(create_app(Hub())) as client:
        with pytest.raises(WebSocketDisconnect):
            with client.websocket_connect("/ws", headers={"origin": "https://evil.example"}):
                pass


def test_slow_client_drops_old_messages_instead_of_blocking():
    hub = Hub()
    queue = hub.subscribe()
    for i in range(1000):
        hub.publish_trade({"i": i})
    assert queue.qsize() == 500
    assert queue.get_nowait()["trade"]["i"] == 500
