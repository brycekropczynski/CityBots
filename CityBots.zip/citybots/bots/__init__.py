from dataclasses import replace

from ..config import RiskConfig
from .base import BaseBot
from .inverse_fvg import InverseFVGBot
from .mean_reversion import MeanReversionBot
from .momentum import MomentumBot
from .random_bot import RandomBot


def build_bots(risk: RiskConfig | None = None, seed: int = 42) -> list[BaseBot]:
    """Every bot shares the cash and position rules; each strategy sets its own stop-loss."""
    risk = risk or RiskConfig()
    with_stop = lambda cls: replace(risk, stop_loss_pct=cls.default_stop)
    return [
        MomentumBot(with_stop(MomentumBot)),
        MeanReversionBot(with_stop(MeanReversionBot)),
        InverseFVGBot(with_stop(InverseFVGBot)),
        RandomBot(with_stop(RandomBot), seed=seed),
    ]


__all__ = ["BaseBot", "InverseFVGBot", "MeanReversionBot", "MomentumBot", "RandomBot", "build_bots"]
