"""Command line entry point: `python -m citybots live` or `python -m citybots replay`."""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from datetime import date, datetime, timedelta, timezone

from .bots import build_bots
from .config import ConfigError, Settings, load_settings
from .data.replay_feed import ReplayFeed, load_alpaca_bars, previous_month
from .data.session import ET, WARMUP_DAYS
from .data.synthetic import synthetic_bars
from .engine import Engine
from .execution.sim_broker import SimBroker
from .hub import Hub
from .storage import Store

log = logging.getLogger("citybots")
LIVE_RUN_ID = "live"  # one continuous run, so bot ledgers survive restarts


def build_replay(args, settings: Settings) -> Engine:
    default_start, default_end = previous_month(datetime.now(ET).date())
    start = date.fromisoformat(args.start) if args.start else default_start
    end = date.fromisoformat(args.end) if args.end else default_end
    if start > end:
        raise ConfigError("--start must be on or before --end.")
    if args.speed < 0:
        raise ConfigError("--speed can't be negative.")

    warm_start, warm_end = start - timedelta(days=WARMUP_DAYS), start - timedelta(days=1)
    if args.synthetic:
        loader = lambda: synthetic_bars(settings.tickers, start, end, args.seed)
        warm_loader = lambda: synthetic_bars(settings.tickers, warm_start, warm_end, args.seed + 1)
    else:
        settings.require_keys()
        loader = lambda: load_alpaca_bars(settings, start, end)
        warm_loader = lambda: load_alpaca_bars(settings, warm_start, warm_end)

    hub = Hub()
    source = "synthetic" if args.synthetic else "alpaca"
    hub.status = {"state": "starting", "message": "", "mode": "replay", "speed": args.speed,
                  "source": source, "start": str(start), "end": str(end)}
    store = Store(settings.db_path)
    run_id = f"replay-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}"
    store.start_run(run_id, "replay", {"start": str(start), "end": str(end), "speed": args.speed,
                                       "source": source, "slippage_bps": settings.slippage_bps})
    print(f"Replay {start} to {end} at {args.speed:g}x from {source} data, run id {run_id}")
    return Engine(build_bots(settings.risk, seed=args.seed), ReplayFeed(loader, args.speed, load_warmup=warm_loader),
                  SimBroker(settings.slippage_bps), store, hub, run_id, "replay")


def build_live(settings: Settings) -> Engine:
    from .data.alpaca_feed import AlpacaFeed, make_data_client
    from .execution.alpaca_broker import AlpacaBroker, make_trading_client, preflight

    settings.require_keys()
    store = Store(settings.db_path)
    store.start_run(LIVE_RUN_ID, "live", {"tickers": list(settings.tickers)})
    bots = build_bots(settings.risk)
    for bot in bots:
        bot.restore(store.trades(LIVE_RUN_ID, bot.name))

    client = make_trading_client(settings)
    for warning in preflight(client, bots):
        log.warning("Position mismatch: %s", warning)

    hub = Hub()
    hub.status = {"state": "starting", "message": "", "mode": "live", "source": "alpaca"}
    feed = AlpacaFeed(settings.tickers, client, make_data_client(settings), settings.poll_seconds)
    return Engine(bots, feed, AlpacaBroker(client), store, hub, LIVE_RUN_ID, "live")


def serve(engine: Engine, port: int) -> None:
    import uvicorn

    from .server import create_app

    print(f"City view: http://127.0.0.1:{port}  (Ctrl-C to stop)")
    uvicorn.run(create_app(engine.hub, engine.run), host="127.0.0.1", port=port, log_level="warning")


def print_results(engine: Engine) -> None:
    print(f"\n{'Bot':<16}{'Return':>10}{'Equity':>13}{'Trades':>8}")
    for row in engine.leaderboard():
        print(f"{row['name']:<16}{row['return_pct']:>9.2f}%{row['equity']:>13,.2f}{row['trades']:>8}")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="citybots", description="Multi-bot paper trading simulator")
    sub = p.add_subparsers(dest="command", required=True)

    live = sub.add_parser("live", help="trade on your Alpaca paper account during market hours")
    live.add_argument("--port", type=int, default=8000)

    replay = sub.add_parser("replay", help="run the bots on historical data; no orders are placed")
    replay.add_argument("--start", help="first day, YYYY-MM-DD (default: first of last month)")
    replay.add_argument("--end", help="last day, YYYY-MM-DD (default: end of last month)")
    replay.add_argument("--speed", type=float, default=100.0, help="multiple of market time; 0 is as fast as possible")
    replay.add_argument("--synthetic", action="store_true", help="use generated prices; no API keys needed")
    replay.add_argument("--seed", type=int, default=42, help="seed for the random bot and synthetic prices")
    replay.add_argument("--no-server", action="store_true", help="skip the city view and print final results")
    replay.add_argument("--port", type=int, default=8000)
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    args = parser().parse_args(argv)
    try:
        settings = load_settings()
        engine = build_live(settings) if args.command == "live" else build_replay(args, settings)
        if args.command == "replay" and args.no_server:
            asyncio.run(engine.run())
            if engine.hub.status.get("state") == "error":
                print(engine.hub.status.get("message"), file=sys.stderr)
                return 1
            print_results(engine)
        else:
            serve(engine, args.port)
            if args.command == "replay":
                print_results(engine)
    except ConfigError as exc:
        print(f"Setup problem: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        pass
    return 0
