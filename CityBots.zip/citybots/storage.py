"""SQLite persistence. Replay runs get their own run_id so they never mix with live."""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone

from .models import Fill

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY, mode TEXT NOT NULL, started_at TEXT NOT NULL, params TEXT
);
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL, mode TEXT NOT NULL,
    bot TEXT NOT NULL, ticker TEXT NOT NULL, side TEXT NOT NULL,
    price REAL NOT NULL, qty REAL NOT NULL, time TEXT NOT NULL,
    reason TEXT, order_id TEXT, realized_pnl REAL
);
CREATE INDEX IF NOT EXISTS trades_run ON trades (run_id, id);
CREATE TABLE IF NOT EXISTS equity_snapshots (
    run_id TEXT NOT NULL, time TEXT NOT NULL, bot TEXT NOT NULL,
    equity REAL NOT NULL, cash REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS equity_run ON equity_snapshots (run_id, time);
"""


class Store:
    def __init__(self, path: str):
        if path != ":memory:":
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)

    def start_run(self, run_id: str, mode: str, params: dict) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO runs VALUES (?,?,?,?)",
            (run_id, mode, datetime.now(timezone.utc).isoformat(), json.dumps(params)),
        )
        self.conn.commit()

    def log_trades(self, run_id: str, mode: str, fills: list[Fill]) -> None:
        self.conn.executemany(
            "INSERT INTO trades (run_id,mode,bot,ticker,side,price,qty,time,reason,order_id,realized_pnl)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            [
                (run_id, mode, f.bot, f.ticker, f.side.value, f.price, f.qty, f.ts.isoformat(),
                 f.reason, f.order_id, f.realized_pnl)
                for f in fills
            ],
        )
        self.conn.commit()

    def log_equity(self, run_id: str, ts: datetime, rows: list[tuple[str, float, float]]) -> None:
        self.conn.executemany(
            "INSERT INTO equity_snapshots VALUES (?,?,?,?,?)",
            [(run_id, ts.isoformat(), bot, equity, cash) for bot, equity, cash in rows],
        )
        self.conn.commit()

    def trades(self, run_id: str, bot: str | None = None) -> list[sqlite3.Row]:
        sql = "SELECT * FROM trades WHERE run_id=?"
        args: list = [run_id]
        if bot:
            sql += " AND bot=?"
            args.append(bot)
        return self.conn.execute(sql + " ORDER BY id", args).fetchall()

    def close(self) -> None:
        self.conn.close()
