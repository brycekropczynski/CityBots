"""Re-checks the picks on real 1-minute bars, with higher costs, sub-periods and more random seeds."""
import json
import multiprocessing as mp
import pickle
from collections import defaultdict
from datetime import date
from statistics import fmean, median

from citybots.bots import build_bots
from citybots.config import load_settings
from citybots.data.replay_feed import load_alpaca_bars

from . import grid, harness

M1 = None
M5 = None
WIN = {}
FAMILIES = ["Momentum", "Mean Reversion", "Inverse FVG", "Random"]
SUB = {"may-jul": (date(2026, 5, 4), date(2026, 7, 31)), "aug-nov": (date(2026, 8, 1), date(2026, 11, 3))}


def job(j):
    kind = j["kind"]
    if kind == "m1":
        warm, live = WIN[("m1", j["win"])]
        return j, harness.run(j["spec"], warm, live, base_minutes=1, slippage_bps=j["bps"])
    warm, live = WIN[("m5", j["win"])]
    return j, harness.run(j["spec"], warm, live, base_minutes=5, slippage_bps=j["bps"])


def main():
    global M1, M5, WIN
    rows = json.load(open("data/research_grid.json"))
    groups = defaultdict(list)
    for r in rows:
        groups[(r["family"], r["id"])].append(r)
    picks, specs = {}, {}
    for fam in FAMILIES:
        scored = []
        for (f, id_), rs in groups.items():
            if f != fam:
                continue
            tr = fmean(x["results"]["train"]["return"] for x in rs)
            ta = fmean(x["results"]["target"]["return"] for x in rs)
            fills = fmean(x["results"]["target"]["fills"] for x in rs)
            if tr > 0 and ta > 0 and fills >= 20:
                sh = min(fmean(x["results"]["train"]["sharpe"] for x in rs), fmean(x["results"]["target"]["sharpe"] for x in rs))
                scored.append((sh, id_, tr, ta))
        scored.sort(reverse=True)
        print(f"{fam}: positive in both: {len(scored)}")
        for s in scored[:4]:
            print("  ", round(s[0], 2), s[1], "train", round(s[2], 2), "target", round(s[3], 2))
        picks[fam] = scored[0][1]
        specs[fam] = groups[(fam, scored[0][1])][0]
    selected = json.load(open("data/research_selected.json"))
    train_specs = {fam: groups[(fam, selected[fam])][0] for fam in FAMILIES}
    json.dump(picks, open("data/research_both.json", "w"), indent=1)

    settings = load_settings()
    M1 = load_alpaca_bars(settings, date(2025, 1, 2), date(2026, 5, 2)) + load_alpaca_bars(settings, date(2026, 5, 3), date(2026, 11, 3))
    M1.sort(key=lambda b: (b.ts, b.ticker))
    M5 = pickle.load(open("data/cache/research_5m.pkl", "rb"))
    WIN = {("m1", "train"): harness.slice_window(M1, harness.TRAIN), ("m1", "target"): harness.slice_window(M1, harness.TARGET)}
    WIN.update({("m5", "train"): harness.slice_window(M5, harness.TRAIN), ("m5", "target"): harness.slice_window(M5, harness.TARGET)})
    for k, w in SUB.items():
        WIN[("m1", k)] = harness.slice_window(M1, w)

    jobs = []
    for label, chosen in (("both", specs), ("train", train_specs)):
        for fam, r in chosen.items():
            s = {k: r[k] for k in ("family", "cls", "stop", "args", "id")}
            if fam == "Random":
                continue
            for win, bps in (("target", 2), ("target", 5), ("target", 10), ("train", 2), ("may-jul", 2), ("aug-nov", 2)):
                jobs.append({"kind": "m1", "label": label, "fam": fam, "spec": s, "win": win, "bps": bps})
    for label, chosen in (("both", specs), ("train", train_specs)):
        base = chosen["Random"]
        for seed in range(30):
            s = {k: base[k] for k in ("family", "cls", "stop", "id")}
            s["args"] = {**base["args"], "seed": 100 + seed}
            for win in ("target", "train"):
                jobs.append({"kind": "m5", "label": label, "fam": "Random", "spec": s, "win": win, "bps": 2, "seed": seed})

    res = defaultdict(list)
    with mp.get_context("fork").Pool(6) as pool:
        for j, m in pool.imap_unordered(job, jobs):
            res[(j["label"], j["fam"], j["win"], j["bps"])].append(m)
    for label, chosen in (("both", specs), ("train", train_specs)):
        print(f"\n=== {label}-selected picks, real 1-minute fills")
        for fam in FAMILIES:
            print(fam, chosen[fam]["id"])
            for (l, f, w, b), ms in sorted(res.items(), key=str):
                if l == label and f == fam:
                    if len(ms) == 1:
                        m = ms[0]
                        print(f"   {w:8} {b}bps return {m['return']:7.2f} sharpe {m['sharpe']:5.2f} dd {m['max_dd']:6.2f} fills {m['fills']:5} win {m['win']:5.1f} stops {m['stops']:3} exp {m['exposure']:4.1f}")
                    else:
                        v = [m["return"] for m in ms]
                        print(f"   {w:8} {b}bps 30 seeds: median {median(v):.2f} mean {fmean(v):.2f} min {min(v):.2f} max {max(v):.2f} positive {sum(x > 0 for x in v)}/30")

    print("\n=== original bots, 1-minute, 2bps")
    for win in ("train", "target"):
        warm, live = WIN[("m1", win)]
        store = harness.NullStore()
        from citybots.engine import Engine
        from citybots.execution.sim_broker import SimBroker
        from citybots.hub import Hub
        import asyncio
        class S(harness.NullStore):
            def log_equity(self, *a): pass
        e = Engine(build_bots(seed=42), harness.WarmReplay(live, []), SimBroker(2.0), S(), Hub(), "r", "replay")
        asyncio.run(e.run())
        print(win, [(r["name"], round(r["return_pct"], 2), r["trades"]) for r in e.leaderboard()])


if __name__ == "__main__":
    main()
