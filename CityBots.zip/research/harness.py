"""Runs one strategy over one date window through the real Engine, without touching the trade log."""
from __future__ import annotations

import asyncio
import math
from datetime import date, timedelta
from statistics import fmean, pstdev

from citybots.config import RiskConfig
from citybots.data.replay_feed import ReplayFeed
from citybots.data.session import ET
from citybots.engine import Engine
from citybots.execution.sim_broker import SimBroker
from citybots.hub import Hub

from . import strategies as S

TRAIN = (date(2025, 5, 5), date(2026, 5, 1))
TARGET = (date(2026, 5, 4), date(2026, 11, 3))
WARMUP_DAYS = 125


class NullStore:
    """Keeps end-of-day equity and exit P&L in memory."""
    def __init__(self):
        self.daily, self.fills, self.wins, self.exits = {}, 0, 0, 0
        self.stops = 0

    def log_trades(self, run_id, mode, fills):
        self.fills += len(fills)
        for f in fills:
            if f.realized_pnl is not None:
                self.exits += 1
                self.wins += f.realized_pnl > 0
                self.stops += f.reason == "stop-loss"

    def log_equity(self, run_id, ts, rows):
        self.daily[ts.astimezone(ET).date()] = rows[0][1:]


class WarmReplay(ReplayFeed):
    def __init__(self, bars, warm):
        super().__init__(lambda: bars, speed=0)
        self.warm = warm

    async def warmup(self):
        return self.warm


def slice_window(all_bars, window):
    start, end = window
    warm_from = start - timedelta(days=WARMUP_DAYS)
    warm, live = [], []
    for b in all_bars:
        d = b.ts.astimezone(ET).date()
        if warm_from <= d < start:
            warm.append(b)
        elif start <= d <= end:
            live.append(b)
    return warm, live


def build(spec, base_minutes):
    cls = getattr(S, spec["cls"])
    risk = RiskConfig(stop_loss_pct=spec["stop"], reentry_cooldown_bars=0 if base_minutes == 5 else 5)
    bot = cls(risk, base_minutes=base_minutes, **spec["args"])
    bot.name = spec["id"]
    return bot


def run(spec, warm, live, base_minutes=5, slippage_bps=2.0):
    bot = build(spec, base_minutes)
    store = NullStore()
    hub = Hub()
    engine = Engine([bot], WarmReplay(live, warm), SimBroker(slippage_bps), store, hub, "r", "replay")
    asyncio.run(engine.run())
    if hub.status["state"] != "finished":
        raise RuntimeError(hub.status)
    equity = [v[0] for v in store.daily.values()]
    exposure = fmean(1 - v[1] / v[0] for v in store.daily.values())
    rets = [b / a - 1 for a, b in zip(equity, equity[1:])]
    peak, dd = equity[0], 0.0
    for e in equity:
        peak = max(peak, e)
        dd = min(dd, e / peak - 1)
    sd = pstdev(rets) if len(rets) > 1 else 0.0
    return {
        "return": round(bot.return_pct, 2),
        "sharpe": round(fmean(rets) / sd * math.sqrt(252), 2) if sd else 0.0,
        "max_dd": round(dd * 100, 2),
        "fills": store.fills,
        "win": round(100 * store.wins / store.exits, 1) if store.exits else 0.0,
        "stops": store.stops,
        "exposure": round(exposure * 100, 1),
    }
