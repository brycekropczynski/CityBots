"""Two-year monthly returns at different position sizes, plus a hindsight ceiling for comparison."""
import argparse
import asyncio
import json
import multiprocessing as mp
from collections import defaultdict
from dataclasses import replace
from datetime import date, timedelta
from statistics import fmean, median

from citybots.bots import InverseFVGBot, MeanReversionBot, MomentumBot, RandomBot
from citybots.config import RiskConfig, load_settings
from citybots.data.replay_feed import load_alpaca_bars
from citybots.data.session import ET, WARMUP_DAYS
from citybots.engine import Engine
from citybots.execution.sim_broker import SimBroker
from citybots.hub import Hub

from .harness import NullStore, WarmReplay

BOTS = [MomentumBot, MeanReversionBot, InverseFVGBot, RandomBot]
SIZES = [0.10, 0.20, 0.33, 0.50, 1.00]
WARM, LIVE = None, None


def month_returns(daily):
    ends = {}
    for d, v in sorted(daily.items()):
        ends[d.strftime("%Y-%m")] = v[0]
    out, prev = {}, 10_000.0
    for month, equity in ends.items():
        out[month] = equity / prev - 1
        prev = equity
    return out


def job(args):
    cls, size = args
    bot = cls(replace(RiskConfig(), stop_loss_pct=cls.default_stop, max_position_pct=size))
    store = NullStore()
    hub = Hub()
    asyncio.run(Engine([bot], WarmReplay(LIVE, WARM), SimBroker(2.0), store, hub, "r", "replay").run())
    assert hub.status["state"] == "finished", hub.status
    eq = [v[0] for _, v in sorted(store.daily.items())]
    peak, dd = eq[0], 0.0
    for e in eq:
        peak = max(peak, e)
        dd = min(dd, e / peak - 1)
    m = month_returns(store.daily)
    return {"bot": cls.name, "size": size, "ret": bot.return_pct, "dd": dd * 100,
            "exposure": fmean(1 - v[1] / v[0] for v in store.daily.values()) * 100,
            "fills": store.fills, "months": {k: v * 100 for k, v in m.items()}}


def main():
    global WARM, LIVE
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=date.fromisoformat, default=date(2024, 11, 3))
    parser.add_argument("--end", type=date.fromisoformat, default=date(2026, 11, 3))
    parser.add_argument("--download-only", action="store_true")
    args = parser.parse_args()
    s = load_settings()
    WARM = load_alpaca_bars(s, args.start - timedelta(days=WARMUP_DAYS), args.start - timedelta(days=1))
    WARM.sort(key=lambda b: b.ts)
    LIVE = load_alpaca_bars(s, args.start, args.end)
    LIVE.sort(key=lambda b: b.ts)  # the 4-year cache was stitched from separately fetched months
    print("bars", len(WARM), len(LIVE), flush=True)
    if args.download_only:
        return
    with mp.get_context("fork").Pool(6) as pool:
        rows = pool.map(job, [(c, z) for c in BOTS for z in SIZES], chunksize=1)
    json.dump(rows, open(f"data/research_monthly_{args.start}_{args.end}.json", "w"))
    for r in rows:
        v = list(r["months"].values())
        print(f"{r['bot']:15} size {r['size']:.2f} ret {r['ret']:8.2f} dd {r['dd']:7.2f} exp {r['exposure']:5.1f} fills {r['fills']:5} "
              f"months+ {sum(x > 0 for x in v)}/{len(v)} avg {fmean(v):6.2f} med {median(v):6.2f} best {max(v):6.2f} worst {min(v):7.2f} >=50%: {sum(x >= 50 for x in v)}")

    closes = defaultdict(dict)
    for b in LIVE:
        closes[b.ticker][b.ts.astimezone(ET).strftime("%Y-%m")] = b.close
    tick_months = defaultdict(list)
    all_rets = []
    for t, c in closes.items():
        months = sorted(c)
        for a, b in zip(months, months[1:]):
            r = (c[b] / c[a] - 1) * 100
            tick_months[b].append((r, t))
            all_rets.append((r, t, b))
    best = {m: max(v) for m, v in tick_months.items()}
    vals = [x[0] for x in best.values()]
    first, last = {}, {}
    for b in LIVE:
        first.setdefault(b.ticker, b.open)
        last[b.ticker] = b.close
    hold = {t: (last[t] / first[t] - 1) * 100 for t in first}
    print("\nhold each ticker:", {t: round(v, 1) for t, v in sorted(hold.items(), key=lambda x: -x[1])})
    print("hold all equal-weight", round(fmean(hold.values()), 2), "SPY", round(hold["SPY"], 2))
    print("\nperfect hindsight, best ticker each month, 100% in:")
    print(" months", len(vals), "avg", round(fmean(vals), 2), "median", round(median(vals), 2), "months>=50%", sum(x >= 50 for x in vals))
    print(" top:", sorted(((round(x[0], 1), x[1], m) for m, x in best.items()), reverse=True)[:5])
    print(" ticker-months >=50%:", [(round(r, 1), t, m) for r, t, m in all_rets if r >= 50], "of", len(all_rets))
    comp = 1.0
    for x in vals:
        comp *= 1 + x / 100
    print(" compounded x", round(comp, 1), "vs 50%/mo x", round(1.5 ** len(vals), 0))


if __name__ == "__main__":
    main()
