"""Plain data types shared by bots, brokers and feeds."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"


@dataclass(frozen=True)
class Bar:
    ticker: str
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True)
class Signal:
    """What a strategy wants. The base class turns it into a sized Decision."""
    side: Side
    reason: str


@dataclass(frozen=True)
class Decision:
    bot: str
    ticker: str
    side: Side
    qty: float
    reason: str
    stop_price: float | None = None  # set only on stop-loss exits


@dataclass
class Fill:
    bot: str
    ticker: str
    side: Side
    qty: float
    price: float
    ts: datetime
    reason: str
    order_id: str = ""
    realized_pnl: float | None = None


@dataclass
class Position:
    qty: float
    avg_price: float
    stop_price: float


@dataclass
class MarketEvent:
    """One step of market time.

    prices: latest price per ticker. opens/lows: open and lowest price this step, which
    let replay fill stops honestly. closed_bars: 1-minute bars completed since the last
    event, which are the only thing strategies act on.
    """
    ts: datetime
    prices: dict[str, float]
    lows: dict[str, float] = field(default_factory=dict)
    opens: dict[str, float] = field(default_factory=dict)
    closed_bars: list[Bar] = field(default_factory=list)
    progress: float | None = None
    closing: bool = False  # the market has shut, so live orders must wait for the next open
