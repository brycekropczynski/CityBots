# CityBots

Four trading bots compete on an Alpaca **paper** account while a pixel-art city shows the
race. Each bot is a building, and its height follows its return.

| Bot | Strategy | Stop-loss |
|---|---|---|
| Momentum | Each Friday's close, holds the top 5 tickers by 20-day return, if that return is positive | 15% |
| Mean Reversion | Buys when daily RSI(2) drops under 10, sells on a close above the 5-day average | 15% |
| Inverse FVG | 30-minute candles: buys the first retest of a bearish gap (0.6% or more) that price closed through, exits when a bullish gap is closed through | 3% |
| Random | Each day, a 10% chance of buying each ticker it doesn't hold, then sells after 10 days (seeded baseline) | 15% |

Every bot starts with $10k and enters at up to 10% of equity per position. Positions can
drift above 10% if they gain value after entry. After a stop-out, a bot sits out that ticker
for 5 minutes.

These strategies came from a search over 281 variants, which `research/` can reproduce. They
were partly chosen using the same 6 months they're tested on, so treat those results as
optimistic.

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[dev]'
cp .env.example .env   # then add your Alpaca paper keys
```

## Run

```bash
# No keys needed: generated prices, watch at http://127.0.0.1:8000
.venv/bin/python -m citybots replay --synthetic

# Last calendar month of real data at 100x (about 82 minutes for a full month)
.venv/bin/python -m citybots replay

# Choose dates or speed; --speed 0 is as fast as possible, --no-server prints results only
.venv/bin/python -m citybots replay --start 2026-10-01 --end 2026-10-10 --speed 500
.venv/bin/python -m citybots replay --speed 0 --no-server

# Place real paper orders during market hours
.venv/bin/python -m citybots live

# Tests
.venv/bin/python -m pytest
```

## How it works

```
Feed → Engine → each bot decides → Broker → Fills → bot ledgers, SQLite, WebSocket → city view
```

- **Same code path:** live and replay share `Engine.step()` and the bots. Only the feed
  (`data/`) and broker (`execution/`) differ.
- **Decisions:** live mode polls every 10 seconds. Stops are checked on every poll, while
  strategies act only when their own 30-minute or daily candle closes.
- **Warm-up:** live and replay load 60 calendar days of earlier bars first, so the daily
  strategies can act from day one. Warm-up never places trades.
- **Orders at the close:** a signal on the day's last bar waits for the next open, in both
  live and replay. Live holds these in memory, so restarting overnight drops them.
- **Shared account:** Alpaca sees one account, so each bot has its own ledger. Orders are
  netted per ticker before sending, and live ledgers rebuild from SQLite after a restart.
- **Replay fills:** signals fill at the next bar's open with 2 bps slippage. Stops fill at
  their level, or at the open if the price gapped through.
- **Paper only:** the client is hard-coded to paper mode, and a non-paper `ALPACA_BASE_URL`
  stops the program.

## Data

Trades are in `data/citybots.sqlite`:

```sql
SELECT bot, ticker, side, price, qty, time, reason FROM trades WHERE mode = 'live' ORDER BY id;
```

Each replay gets its own `run_id`. Equity history is in `equity_snapshots`.

## Limits

- Replay results come from one month and simple fill assumptions, so they don't predict
  live or future performance. `--synthetic` prices are invented and only test the software.
- Live data uses Alpaca's free IEX feed, which covers a small share of US volume. Replay
  uses consolidated data, so the two can behave differently.
- Stops are checked by the engine, so a live stop can fill well below its level.
- On Alpaca's free feed, a thin minute can be missing. A candle missing its last minute
  closes when the next bar arrives, so its signal can fire a little late.
- Early market closes aren't filtered from replay data, and only the bots' own ledgers are
  reconciled: anything else held in the account is reported as a mismatch at startup.
