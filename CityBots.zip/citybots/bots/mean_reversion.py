from __future__ import annotations

from statistics import fmean

from ..models import Side, Signal
from .timeframe import SESSION_MINUTES, TimeframeBot

RSI_HISTORY = 30


def rsi2(closes: list[float]) -> float:
    """2-period Relative Strength Index with Wilder smoothing."""
    up = down = 0.0
    for i, (a, b) in enumerate(zip(closes, closes[1:])):
        gain, loss = max(b - a, 0), max(a - b, 0)
        up, down = (gain, loss) if i == 0 else ((up + gain) / 2, (down + loss) / 2)
    return 100.0 if down == 0 else 100 - 100 / (1 + up / down)


class MeanReversionBot(TimeframeBot):
    """Buys a sharp daily pullback (RSI(2) under 10); sells on a close above the 5-day average."""
    name = "Mean Reversion"
    default_stop = 0.15

    def __init__(self, risk=None, base_minutes=1, entry=10):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.entry = entry

    def on_candle(self, ticker, candles):
        closes = [c.close for c in candles[-RSI_HISTORY:]]
        if len(closes) < RSI_HISTORY:
            return None
        if closes[-1] > fmean(closes[-5:]):
            return Signal(Side.SELL, "close above 5-day average")
        if rsi2(closes) < self.entry:
            return Signal(Side.BUY, "RSI(2) pullback")
        return None
