from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from ..models import Side, Signal
from .timeframe import TimeframeBot


@dataclass
class Zone:
    bottom: float
    top: float
    born: int


class GapTracker:
    """Tracks fair value gaps: price ranges skipped by three consecutive candles.

    - A bearish gap closed through to the upside becomes support, and its first retest is
      a buy signal.
    - A bullish gap closed through to the downside becomes resistance, which is an exit
      signal, because the bots are long-only.
    """

    def __init__(self, min_gap_pct=0.006, max_age=40):
        self.min_gap_pct = min_gap_pct
        self.max_age = max_age
        self.bullish: dict[str, list[Zone]] = defaultdict(list)
        self.bearish: dict[str, list[Zone]] = defaultdict(list)
        self.support: dict[str, list[Zone]] = defaultdict(list)
        self.count: dict[str, int] = defaultdict(int)

    def update(self, ticker, candles) -> Signal | None:
        self.count[ticker] += 1
        now = self.count[ticker]
        candle = candles[-1]
        result = None

        # Retests are checked before new inversions, so a candle can't retest the zone it just inverted.
        remaining = []
        for z in self.support[ticker]:
            if now - z.born > self.max_age or candle.close < z.bottom:
                continue
            if candle.low <= z.top:
                result = Signal(Side.BUY, "inverse FVG retest")
                continue
            remaining.append(z)
        self.support[ticker] = remaining

        still_bearish = []
        for z in self.bearish[ticker]:
            if now - z.born > self.max_age:
                continue
            if candle.close > z.top:
                self.support[ticker].append(Zone(z.bottom, z.top, now))
            else:
                still_bearish.append(z)
        self.bearish[ticker] = still_bearish

        still_bullish = []
        for z in self.bullish[ticker]:
            if now - z.born > self.max_age:
                continue
            if candle.close < z.bottom:
                result = Signal(Side.SELL, "bearish inverse FVG")
            else:
                still_bullish.append(z)
        self.bullish[ticker] = still_bullish

        if len(candles) >= 3:
            first, third = candles[-3], candles[-1]
            floor = third.close * self.min_gap_pct
            if third.low - first.high >= floor:
                self.bullish[ticker].append(Zone(first.high, third.low, now))
            elif first.low - third.high >= floor:
                self.bearish[ticker].append(Zone(third.high, first.low, now))
        return result


class InverseFVGBot(TimeframeBot):
    """Inverse fair value gaps on 30-minute candles, ignoring gaps under 0.6%.

    Overnight jumps can count as gaps here. That matches the version that was tested.
    """
    name = "Inverse FVG"
    default_stop = 0.03

    def __init__(self, risk=None, base_minutes=1, tf=30, min_gap=0.006):
        super().__init__(risk, tf, base_minutes)
        self.gaps = GapTracker(min_gap)

    def on_candle(self, ticker, candles):
        return self.gaps.update(ticker, candles)
