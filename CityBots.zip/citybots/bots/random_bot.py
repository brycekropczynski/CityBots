from __future__ import annotations

import random
from collections import defaultdict

from ..models import Side, Signal
from .timeframe import SESSION_MINUTES, TimeframeBot


class RandomBot(TimeframeBot):
    """The baseline: random daily entries, each held for 10 days. A strategy that can't
    beat this over time has no demonstrated edge."""
    name = "Random"
    default_stop = 0.15

    def __init__(self, risk=None, base_minutes=1, prob=0.10, hold=10, seed=42):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.rng = random.Random(seed)
        self.prob = prob
        self.hold = hold
        self.held = defaultdict(int)

    def on_candle(self, ticker, candles):
        roll = self.rng.random()  # always drawn, so runs repeat regardless of holdings
        if ticker in self.positions:
            self.held[ticker] += 1
            return Signal(Side.SELL, "hold period over") if self.held[ticker] >= self.hold else None
        self.held[ticker] = 0
        return Signal(Side.BUY, "coin flip") if roll < self.prob else None
