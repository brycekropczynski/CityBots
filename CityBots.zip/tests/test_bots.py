from dataclasses import replace
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest

from citybots.bots import InverseFVGBot, MeanReversionBot, MomentumBot, RandomBot, build_bots
from citybots.bots.inverse_fvg import GapTracker
from citybots.bots.mean_reversion import rsi2
from citybots.bots.timeframe import TimeframeBot
from citybots.config import RiskConfig
from citybots.models import Bar, Fill, Side

ET = ZoneInfo("America/New_York")
MONDAY = datetime(2026, 6, 1, 9, 30, tzinfo=ET)


def weekdays(n, start=MONDAY):
    days, day = [], start
    while len(days) < n:
        if day.weekday() < 5:
            days.append(day)
        day += timedelta(days=1)
    return days


def daily(ticker, day, close, open_=None, low=None, high=None):
    """A whole session as one 390-minute bar; base_minutes=390 makes each one a daily candle."""
    open_ = close if open_ is None else open_
    return Bar(ticker, day.astimezone(timezone.utc), open_, high or max(open_, close), low or min(open_, close), close, 1000.0)


def candle(i, close, open_=None, low=None, high=None, ticker="AAA"):
    open_ = close if open_ is None else open_
    return Bar(ticker, (MONDAY + timedelta(minutes=30 * i)).astimezone(timezone.utc), open_,
               high or max(open_, close), low or min(open_, close), close, 1000.0)


def feed_days(bot, closes, ticker="AAA", start=MONDAY):
    return [bot.on_bar(daily(ticker, d, c)) for d, c in zip(weekdays(len(closes), start), closes)]


def buy(bot, ticker="AAA", qty=10.0, price=100.0):
    bot.apply_fill(Fill(bot.name, ticker, Side.BUY, qty, price, MONDAY, "test"))


class Recorder(TimeframeBot):
    def __init__(self, tf):
        super().__init__(tf=tf)
        self.closed = []

    def on_candle(self, ticker, candles):
        self.closed.append(candles[-1])


def minute(offset, price=100.0, day=MONDAY):
    return Bar("AAA", (day + timedelta(minutes=offset)).astimezone(timezone.utc), price, price + 1, price - 1, price, 10.0)


def test_candles_close_on_their_last_minute_and_merge_ohlcv():
    bot = Recorder(tf=30)
    for i in range(29):
        bot.on_bar(minute(i, 100.0 + i))
    assert bot.closed == []
    bot.on_bar(minute(29, 90.0))
    c = bot.closed[0]
    assert (c.open, c.close, c.volume) == (100.0, 90.0, 300.0)
    assert c.high == 129.0 and c.low == 89.0


def test_daily_candle_closes_at_last_minute_of_session():
    bot = Recorder(tf=390)
    for i in range(389):
        bot.on_bar(minute(i))
    assert bot.closed == []
    bot.on_bar(minute(389))
    assert len(bot.closed) == 1


def test_missing_last_minute_closes_candle_late_instead_of_losing_it():
    bot = Recorder(tf=390)
    for i in range(388):  # 15:58 and 15:59 never arrive
        bot.on_bar(minute(i))
    bot.on_bar(minute(0, day=MONDAY + timedelta(days=1)))
    assert len(bot.closed) == 1 and bot.closed[0].ts.astimezone(ET).day == 1


def test_rsi2_extremes():
    assert rsi2([10, 9, 8, 7, 6]) == pytest.approx(0.0)
    assert rsi2([1, 2, 3, 4, 5]) == 100.0


def test_mean_reversion_buys_pullback_and_sells_bounce():
    bot = MeanReversionBot(base_minutes=390)
    assert all(d is None for d in feed_days(bot, [100.0 + i for i in range(29)]))
    days = weekdays(32)
    assert bot.on_bar(daily("AAA", days[29], 100.0)).side is Side.BUY
    buy(bot, price=100.0)
    assert bot.on_bar(daily("AAA", days[30], 125.0)).side is Side.SELL


def test_mean_reversion_waits_for_full_history():
    assert all(d is None for d in feed_days(MeanReversionBot(base_minutes=390), [100.0 - i for i in range(29)]))


def rotation_decisions(day_index):
    bot = MomentumBot(base_minutes=390, top=1)
    days = weekdays(day_index + 1)
    decisions = {}
    for i, day in enumerate(days):
        for ticker, growth in (("AAA", 1.02), ("BBB", 1.00), ("CCC", 0.99)):
            d = bot.on_bar(daily(ticker, day, 100.0 * growth ** i))
            if i == day_index and d:
                decisions[ticker] = d
    return bot, days[day_index], decisions


def test_momentum_only_acts_on_friday_and_buys_the_strongest():
    _, day, decisions = rotation_decisions(24)  # Friday
    assert day.weekday() == 4
    assert decisions["AAA"].side is Side.BUY and "BBB" not in decisions
    _, thursday, none = rotation_decisions(23)
    assert thursday.weekday() == 3 and none == {}


def test_momentum_won_t_buy_a_falling_ticker_even_if_ranked_top():
    bot = MomentumBot(base_minutes=390, top=1)
    days = weekdays(25)
    results = [bot.on_bar(daily("CCC", day, 100.0 * 0.99 ** i)) for i, day in enumerate(days)]
    assert results[-1] is None or results[-1].side is Side.SELL


def test_momentum_sells_when_dropped_from_top():
    bot = MomentumBot(base_minutes=390, top=1)
    days = weekdays(25)
    for i, day in enumerate(days[:-1]):
        bot.on_bar(daily("AAA", day, 100.0 + i))
        bot.on_bar(daily("BBB", day, 100.0 + 3 * i))
    buy(bot)
    assert bot.on_bar(daily("AAA", days[-1], 125.0)).side is Side.SELL


def gap_candles():
    return [
        candle(0, 100.0, high=100.5, low=99.5),
        candle(1, 97.0, open_=99.5, high=99.5, low=96.5),
        candle(2, 96.0, open_=96.5, high=97.0, low=95.5),  # bearish gap between 97.0 and 99.5
    ]


def run_candles(tracker, candles):
    return [tracker.update("AAA", candles[: i + 1]) for i in range(len(candles))]


def test_gap_buy_only_on_retest_after_inversion():
    seq = gap_candles() + [
        candle(3, 100.0, open_=96.0, high=100.2, low=96.0),  # inverts, no entry yet
        candle(4, 101.0, open_=100.0, high=101.2, low=100.0),  # above the zone
        candle(5, 100.0, open_=101.0, high=101.0, low=99.2),  # retest
    ]
    out = run_candles(GapTracker(), seq)
    assert out[:5] == [None] * 5
    assert out[5].side is Side.BUY


def test_gap_zone_invalidated_by_close_below_it():
    seq = gap_candles() + [
        candle(3, 100.0, open_=96.0, high=100.2, low=96.0),
        candle(4, 96.0, open_=100.0, high=100.0, low=95.5),
    ]
    assert run_candles(GapTracker(), seq)[-1] is None


def test_gap_bullish_inversion_exits():
    seq = [
        candle(0, 100.0, high=100.5, low=99.5),
        candle(1, 103.0, open_=100.5, high=103.5, low=100.5),
        candle(2, 104.0, open_=103.0, high=104.5, low=103.0),  # bullish gap between 100.5 and 103.0
        candle(3, 100.0, open_=104.0, high=104.0, low=99.8),
    ]
    assert run_candles(GapTracker(), seq)[-1].side is Side.SELL


def test_small_gaps_are_ignored():
    seq = [
        candle(0, 100.0, high=100.1, low=99.9),
        candle(1, 100.2, open_=100.1, high=100.3, low=100.1),
        candle(2, 100.5, open_=100.3, high=100.6, low=100.3),  # 0.2% gap, under the 0.6% floor
    ]
    tracker = GapTracker()
    run_candles(tracker, seq)
    assert not tracker.bullish["AAA"]


def test_inverse_fvg_runs_on_30_minute_candles():
    bot = InverseFVGBot()
    for i in range(29):
        bot.on_bar(minute(i))
    assert bot.gaps.count["AAA"] == 0
    bot.on_bar(minute(29))
    assert bot.gaps.count["AAA"] == 1


def test_random_bot_repeats_with_same_seed():
    closes = [100.0] * 200
    run = lambda: [d.side if d else None for d in feed_days(RandomBot(seed=1, base_minutes=390), closes)]
    assert run() == run()
    assert any(run())


def test_random_bot_sells_after_hold_period():
    bot = RandomBot(seed=1, base_minutes=390, prob=0.0, hold=3)
    buy(bot)
    results = feed_days(bot, [100.0] * 3)
    assert results[:2] == [None, None] and results[2].side is Side.SELL


def test_build_bots_sets_each_stop_and_shared_rules():
    stops = {b.name: b.risk.stop_loss_pct for b in build_bots()}
    assert stops == {"Momentum": 0.15, "Mean Reversion": 0.15, "Inverse FVG": 0.03, "Random": 0.15}
    for bot in build_bots():
        assert bot.cash == 10_000 and bot.risk.max_position_pct == 0.10


def test_position_size_never_exceeds_cap():
    bot = RandomBot(seed=1, prob=1.0, base_minutes=390)
    decision = feed_days(bot, [101.0])[0]
    assert decision.qty * 101.0 <= 0.10 * bot.equity


def test_buys_in_one_round_cannot_overspend_cash():
    bot = RandomBot(RiskConfig(max_position_pct=0.6), prob=1.0, base_minutes=390)
    bot.begin_round()
    decisions = [bot.on_bar(daily(t, MONDAY, 100.0)) for t in ("AAA", "BBB", "CCC")]
    assert sum(d.qty * 100.0 for d in decisions if d) <= bot.cash


def test_stop_triggers_and_cooldown_blocks_reentry():
    bot = RandomBot(replace(RiskConfig(), stop_loss_pct=0.02), prob=1.0, hold=99, base_minutes=390)
    buy(bot)
    assert bot.positions["AAA"].stop_price == pytest.approx(98.0)
    assert bot.check_stops({"AAA": 98.5}) == []
    stop = bot.check_stops({"AAA": 97.9})[0]
    assert stop.side is Side.SELL and stop.stop_price == pytest.approx(98.0)
    bot.apply_fill(Fill(bot.name, "AAA", Side.SELL, 10.0, 98.0, MONDAY, "stop-loss"))
    assert "AAA" not in bot.positions
    results = feed_days(bot, [98.0] * 6)
    assert results[:5] == [None] * 5 and results[5].side is Side.BUY


def test_ledger_accounting():
    bot = RandomBot()
    buy(bot, qty=10.0, price=100.0)
    bot.update_marks({"AAA": 110.0})
    assert bot.equity == pytest.approx(10_100.0)
    assert bot.return_pct == pytest.approx(1.0)
    fill = Fill(bot.name, "AAA", Side.SELL, 10.0, 110.0, MONDAY, "exit")
    bot.apply_fill(fill)
    assert fill.realized_pnl == pytest.approx(100.0)
    assert bot.cash == pytest.approx(10_100.0)
