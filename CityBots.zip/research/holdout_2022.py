"""Final check on data never used for selection. Picks are frozen; nothing here feeds back into them."""
import json
import multiprocessing as mp
from datetime import date
from statistics import fmean, median
from collections import defaultdict

from citybots.config import load_settings
from citybots.data.replay_feed import load_alpaca_bars

from . import harness
from .prepare_data import bucket
from citybots.models import Bar

WINDOW = (date(2022, 1, 3), date(2022, 12, 30))
W = None


def job(j):
    return j, harness.run(j["spec"], *W, base_minutes=5, slippage_bps=2.0)


def main():
    global W
    bars = load_alpaca_bars(load_settings(), date(2021, 8, 30), date(2022, 12, 30))
    print("1-min bars", len(bars), flush=True)
    groups = defaultdict(list)
    for b in bars:
        groups[(b.ticker, bucket(b.ts))].append(b)
    m5 = []
    for (t, ts), g in groups.items():
        g.sort(key=lambda b: b.ts)
        m5.append(Bar(t, ts, g[0].open, max(b.high for b in g), min(b.low for b in g), g[-1].close, sum(b.volume for b in g)))
    m5.sort(key=lambda b: (b.ts, b.ticker))
    del bars, groups
    W = harness.slice_window(m5, WINDOW)
    first, last = {}, {}
    for b in W[1]:
        first.setdefault(b.ticker, b.open)
        last[b.ticker] = b.close
    bh = {t: round((last[t] / first[t] - 1) * 100, 1) for t in first}
    print("tickers", len(bh), bh)
    print("buy & hold 2022 equal-weight", round(fmean(bh.values()), 2))

    rows = json.load(open("data/research_grid.json"))
    by_id = {}
    for r in rows:
        by_id.setdefault(r["id"], r)
    jobs = []
    for label, path in (("both", "data/research_both.json"), ("train", "data/research_selected.json")):
        for fam, id_ in json.load(open(path)).items():
            base = by_id[id_]
            s = {k: base[k] for k in ("family", "cls", "stop", "id")}
            if fam == "Random":
                for seed in range(30):
                    jobs.append({"label": label, "fam": fam, "spec": {**s, "args": {**base["args"], "seed": 100 + seed}}})
            else:
                jobs.append({"label": label, "fam": fam, "spec": {**s, "args": base["args"]}})
    res = defaultdict(list)
    with mp.get_context("fork").Pool(6) as pool:
        for j, m in pool.imap_unordered(job, jobs):
            res[(j["label"], j["fam"], j["spec"]["id"])].append(m)
    for (label, fam, id_), ms in sorted(res.items()):
        if len(ms) == 1:
            print(label, fam, id_, ms[0])
        else:
            v = [m["return"] for m in ms]
            print(label, fam, id_, f"30 seeds median {median(v)} min {min(v)} max {max(v)} positive {sum(x > 0 for x in v)}/30")


if __name__ == "__main__":
    main()
