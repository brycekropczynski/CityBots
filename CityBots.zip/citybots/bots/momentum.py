from __future__ import annotations

from ..data.session import ET
from ..models import Side, Signal
from .timeframe import SESSION_MINUTES, TimeframeBot

FRIDAY = 4


class MomentumBot(TimeframeBot):
    """Weekly rotation: at Friday's close, holds the top 5 tickers by 20-day return."""
    name = "Momentum"
    default_stop = 0.15

    def __init__(self, risk=None, base_minutes=1, lookback=20, top=5):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.lookback = lookback
        self.top = top

    def on_candle(self, ticker, candles):
        day = candles[-1].ts.astimezone(ET).date()
        if day.weekday() != FRIDAY:
            return None
        # Ranks on closes before today, so the order tickers arrive in can't change the result.
        scores = {}
        for t, series in self.candles.items():
            closes = [c.close for c in series[-self.lookback - 2:] if c.ts.astimezone(ET).date() < day]
            if len(closes) > self.lookback:
                scores[t] = closes[-1] / closes[-self.lookback - 1]
        if ticker not in scores:
            return None
        best = sorted(scores, key=scores.get, reverse=True)[:self.top]
        if ticker in best and scores[ticker] > 1:
            return Signal(Side.BUY, "top 20-day return")
        return Signal(Side.SELL, "dropped from top")
