"""FastAPI app: serves the city view and streams engine updates over a WebSocket."""
from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Callable, Coroutine
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse

import anyio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .hub import Hub

STATIC = Path(__file__).parent / "static"


def create_app(hub: Hub, run_engine: Callable[[], Coroutine] | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(_: FastAPI):
        task = asyncio.create_task(run_engine()) if run_engine else None
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    app = FastAPI(title="CityBots", lifespan=lifespan)

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/state")
    async def state():
        return hub.snapshot()

    @app.websocket("/ws")
    async def stream(ws: WebSocket):
        # Stops other websites open in the browser from reading this stream.
        origin = ws.headers.get("origin")
        if origin and urlparse(origin).netloc != ws.headers.get("host"):
            await ws.close(code=1008)
            return
        await ws.accept()
        queue = hub.subscribe()

        async def send():
            with contextlib.suppress(WebSocketDisconnect, RuntimeError):  # client already gone
                await ws.send_json(hub.snapshot())
                while True:
                    await ws.send_json(await queue.get())
            tasks.cancel_scope.cancel()

        async def receive():
            with contextlib.suppress(WebSocketDisconnect):
                while True:
                    await ws.receive_text()
            tasks.cancel_scope.cancel()

        try:
            async with anyio.create_task_group() as tasks:
                tasks.start_soon(send)
                tasks.start_soon(receive)
        finally:
            hub.unsubscribe(queue)

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app
