// Draws the pixel-art city onto a low-resolution canvas. Knows nothing about the WebSocket:
// app.js calls City.setBots() and City.flash().
const City = (() => {
  const GLYPHS = {
    A:"010101111101101",B:"110101110101110",C:"011100100100011",D:"110101101101110",E:"111100110100111",
    F:"111100110100100",G:"011100101101011",H:"101101111101101",I:"111010010010111",J:"001001001101010",
    K:"101101110101101",L:"100100100100111",M:"101111111101101",N:"110101101101101",O:"010101101101010",
    P:"110101110100100",Q:"010101101110011",R:"110101110101101",S:"011100010001110",T:"111010010010010",
    U:"101101101101011",V:"101101101010010",W:"101101111111101",X:"101101010101101",Y:"101101010010010",
    Z:"111001010100111",0:"111101101101111",1:"010110010010111",2:"110001010100111",3:"110001010001110",
    4:"101101111001001",5:"111100110001110",6:"011100111101111",7:"111001010010010",8:"111101111101111",
    9:"111101111001110","+":"000010111010000","-":"000000111000000",".":"000000000000010",
    "%":"101001010100101","$":"011110010011110","=":"000111000111000",":":"000010000010000"," ":"000000000000000",
  };
  const FLOOR_PX = 6, STREET_PX = 24, TOP_MARGIN = 26;
  const STYLES = {
    "Momentum":       { short: "MOMENTUM", body: "#3b5bdb", dark: "#2b44a8", light: "#5c7cfa", accent: "#74c0fc", roof: "antenna" },
    "Mean Reversion": { short: "MEAN REV", body: "#a8553a", dark: "#7f3f2b", light: "#c9704f", accent: "#ffc078", roof: "tank" },
    "Inverse FVG":    { short: "INV FVG",  body: "#6b3fa0", dark: "#4f2d78", light: "#8a5bc4", accent: "#e599f7", roof: "crown" },
    "Random":         { short: "RANDOM",   body: "#2f8f83", dark: "#226b62", light: "#44b3a4", accent: "#96f2d7", roof: "crane" },
  };
  const FALLBACK = { short: "BOT", body: "#667", dark: "#445", light: "#889", accent: "#ccd", roof: "antenna" };
  const SKY = {
    night: [[10, 15, 38], [20, 26, 60], [37, 37, 82]],
    dawn:  [[42, 31, 79], [122, 63, 109], [240, 146, 106]],
    noon:  [[47, 111, 181], [95, 168, 217], [168, 216, 234]],
    dusk:  [[39, 34, 79], [154, 74, 110], [242, 162, 92]],
  };
  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

  let canvas, ctx, W = 320, H = 180, groundY = 156, maxFloors = 20, midFloors = 10, span = 0.25;
  let sky = SKY.night.map(c => [...c]), sessionFrac = null;
  let stars = [], skyline = [], cars = [], lastFrame = 0;
  const buildings = new Map();

  const rect = (x, y, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
  const rgb = c => `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`;
  const lerp = (a, b, t) => a + (b - a) * t;
  const hash = (a, b, c) => { const v = Math.sin(a * 127.1 + b * 311.7 + c * 74.7) * 43758.5453; return v - Math.floor(v); };

  function text(str, x, y, color) {
    ctx.fillStyle = color;
    let cx = Math.round(x);
    for (const ch of str.toUpperCase()) {
      const g = GLYPHS[ch] || GLYPHS[" "];
      for (let i = 0; i < 15; i++) if (g[i] === "1") ctx.fillRect(cx + i % 3, Math.round(y) + ((i / 3) | 0), 1, 1);
      cx += 4;
    }
  }
  const textWidth = s => s.length * 4 - 1;

  function resize() {
    const box = canvas.parentElement.getBoundingClientRect();
    const scale = Math.max(2, Math.min(5, Math.floor(Math.min(box.width / 300, box.height / 170))));
    W = Math.max(120, Math.floor(box.width / scale));
    H = Math.max(90, Math.floor(box.height / scale));
    canvas.width = W; canvas.height = H;
    groundY = H - STREET_PX;
    maxFloors = Math.max(6, Math.floor((groundY - TOP_MARGIN) / FLOOR_PX));
    midFloors = Math.round(maxFloors / 2);
    stars = Array.from({ length: Math.floor(W / 5) }, (_, i) => ({ x: hash(i, 1, 2) * W, y: hash(i, 3, 4) * groundY * .7, p: hash(i, 5, 6) }));
    skyline = [];
    for (let x = 0, i = 0; x < W; i++) {
      const w = 10 + Math.floor(hash(i, 7, 8) * 18);
      skyline.push({ x, w, h: 12 + hash(i, 9, 10) * groundY * .42, back: true });
      x += w;
    }
    for (let x = -4, i = 0; x < W; i++) {
      const w = 8 + Math.floor(hash(i, 11, 12) * 16);
      skyline.push({ x, w, h: 8 + hash(i, 13, 14) * groundY * .26, back: false });
      x += w;
    }
    cars = Array.from({ length: Math.max(3, Math.floor(W / 70)) }, (_, i) => ({
      x: hash(i, 15, 16) * W, lane: i % 2, speed: 14 + hash(i, 17, 18) * 16,
      color: ["#e03131", "#f8f9fa", "#fcc419", "#1c7ed6", "#37b24d"][i % 5],
    }));
    layout();
  }

  function layout() {
    const biggest = Math.max(0, ...[...buildings.values()].map(b => Math.abs(b.ret)));
    span = Math.max(0.25, biggest * 1.15);
    const room = maxFloors - midFloors - 1;
    for (const b of buildings.values()) {
      const floors = midFloors + Math.round(b.ret / span * room);
      b.target = Math.max(2, Math.min(maxFloors, floors)) * FLOOR_PX;
      if (b.height == null || reducedMotion) b.height = b.target;
    }
  }

  function setBots(bots) {
    for (const bot of bots) {
      let b = buildings.get(bot.name);
      if (!b) {
        b = { name: bot.name, style: STYLES[bot.name] || FALLBACK, seed: buildings.size + 1, ret: 0, height: null, target: 0, flashAt: -1e9, flashSide: "buy" };
        buildings.set(bot.name, b);
      }
      b.ret = bot.return_pct;
    }
    layout();
  }

  function flash(botName, side) {
    const b = buildings.get(botName);
    if (b) { b.flashAt = performance.now(); b.flashSide = side; }
  }

  function setMarketTime(iso) {
    if (!iso) { sessionFrac = null; return; }
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "numeric", minute: "numeric", hourCycle: "h23" }).formatToParts(new Date(iso));
    const get = t => +parts.find(p => p.type === t).value;
    const f = (get("hour") * 60 + get("minute") - 570) / 390;
    sessionFrac = f >= 0 && f <= 1 ? f : null;
  }

  function targetSky() {
    const f = sessionFrac;
    if (f == null) return SKY.night;
    const mix = (a, b, t) => a.map((c, i) => c.map((v, j) => lerp(v, b[i][j], t)));
    if (f < .15) return mix(SKY.dawn, SKY.noon, f / .15);
    if (f > .8) return mix(SKY.noon, SKY.dusk, (f - .8) / .2);
    return SKY.noon;
  }

  function drawSky(t, dt) {
    const goal = targetSky();
    const blend = reducedMotion ? 1 : 1 - Math.exp(-dt * 2.5);  // time-based, so frame rate doesn't matter
    sky.forEach((c, i) => c.forEach((v, j) => { c[j] = lerp(v, goal[i][j], blend); }));
    const bands = 12, h = Math.ceil(groundY / bands);
    for (let i = 0; i < bands; i++) {
      const p = i / (bands - 1) * 2, lo = Math.min(1, Math.floor(p)), m = p - lo;
      const c = sky[lo].map((v, j) => lerp(v, sky[lo + 1][j], m));
      rect(0, i * h, W, h, rgb(c));
    }
    const darkness = 1 - Math.min(1, sky[1][2] / 200);
    if (darkness > .55) {
      for (const s of stars) {
        const on = reducedMotion || Math.sin(t / 900 + s.p * 40) > -.6;
        if (on) rect(s.x, s.y, 1, 1, "#d7dcff");
      }
    }
    if (sessionFrac != null) {
      const x = lerp(12, W - 20, sessionFrac);
      const y = groundY * .55 - Math.sin(sessionFrac * Math.PI) * groundY * .42;
      rect(x + 1, y, 6, 8, "#ffe066"); rect(x, y + 1, 8, 6, "#ffe066");
    } else {
      rect(W - 28, 12, 7, 9, "#e9ecef"); rect(W - 29, 13, 9, 7, "#e9ecef"); rect(W - 26, 12, 7, 7, rgb(sky[0]));
    }
    return darkness;
  }

  function drawSkyline(dark) {
    const back = rgb(sky[2].map(v => v * .62)), front = rgb(sky[2].map(v => v * .42));
    for (const s of skyline) rect(s.x, groundY - s.h, s.w, s.h, s.back ? back : front);
    if (dark > .3) {
      skyline.filter(s => !s.back).forEach((s, i) => {
        for (let y = groundY - s.h + 3; y < groundY - 2; y += 5)
          for (let x = s.x + 2; x < s.x + s.w - 2; x += 4)
            if (hash(i, x, y) > .78) rect(x, y, 1, 2, "#ffd43b");
      });
    }
  }

  function drawRoof(b, x, w, top, t) {
    const s = b.style, cx = x + (w >> 1);
    if (s.roof === "antenna") {
      rect(cx - 4, top - 3, 8, 3, s.dark); rect(cx, top - 12, 1, 9, "#ced4da");
      if (reducedMotion || Math.sin(t / 350) > 0) rect(cx - 1, top - 14, 3, 2, "#ff6b6b");
    } else if (s.roof === "tank") {
      rect(cx + 2, top - 3, 1, 3, "#495057"); rect(cx + 9, top - 3, 1, 3, "#495057");
      rect(cx + 1, top - 10, 10, 7, "#8d6e63"); rect(cx + 1, top - 11, 10, 1, "#5d4037"); rect(cx + 3, top - 10, 1, 7, "#a1887f");
    } else if (s.roof === "crown") {
      rect(x + 3, top - 3, w - 6, 3, s.dark); rect(x + 7, top - 6, w - 14, 3, s.body); rect(cx - 3, top - 9, 6, 3, s.light); rect(cx - 1, top - 12, 2, 3, s.accent);
    } else {
      rect(cx - 8, top - 12, 1, 12, "#fcc419"); rect(cx - 12, top - 12, 26, 1, "#fcc419");
      rect(cx + 11, top - 11, 1, 5, "#ced4da"); rect(cx + 9, top - 6, 5, 2, "#495057");
    }
  }

  function drawBuilding(b, x, w, t, dark) {
    const s = b.style, h = Math.round(b.height), top = groundY - h;
    drawRoof(b, x, w, top, t);
    rect(x, top, w, h, s.body);
    rect(x, top, 1, h, s.light);
    rect(x + w - 2, top, 2, h, s.dark);
    rect(x, top, w, 1, s.light);

    const elapsed = t - b.flashAt, flashing = elapsed < 650;
    const flashColor = b.flashSide === "buy" ? "#40f07a" : "#ff4d4d";
    const cols = Math.max(1, Math.floor((w - 5) / 5));
    const inset = Math.floor((w - (cols * 5 - 2)) / 2);
    const floors = Math.floor(h / FLOOR_PX);
    for (let f = 1; f < floors; f++) {
      const y = groundY - (f + 1) * FLOOR_PX + 2;
      for (let c = 0; c < cols; c++) {
        const wx = x + inset + c * 5;
        let lit = hash(b.seed, f, c) < .18 + dark * .5;
        if (!reducedMotion && hash(b.seed, c, f + Math.floor(t / 3000)) > .985) lit = !lit;
        let color = lit ? "#ffe066" : dark > .4 ? "#1c2340" : s.dark;
        if (s.roof === "crane" && lit) color = ["#ffe066", "#ffa8a8", "#a5d8ff"][Math.floor(hash(c, f, 3) * 3)];
        rect(wx, y, 3, 3, flashing ? flashColor : color);
      }
    }
    // Lobby
    const cx = x + (w >> 1);
    rect(x + 2, groundY - 2, w - 4, 2, s.dark);
    rect(cx - 3, groundY - 5, 6, 5, "#14182e");
    rect(cx - 5, groundY - 6, 10, 1, s.accent);

    if (flashing) {
      const step = elapsed < 220 ? .55 : elapsed < 440 ? .35 : .18;
      ctx.globalAlpha = step; rect(x, top, w, h, flashColor); ctx.globalAlpha = 1;
      rect(x - 1, top - 1, w + 2, 1, flashColor); rect(x - 1, top, 1, h, flashColor); rect(x + w, top, 1, h, flashColor);
      drawArrow(cx, Math.min(groundY - 14, top + 5), b.flashSide === "buy");
    }

    const ret = (b.ret >= 0 ? "+" : "") + b.ret.toFixed(2) + "%";
    const rx = cx - textWidth(ret) / 2, ry = Math.max(1, top - 22);
    rect(rx - 2, ry - 1, textWidth(ret) + 4, 7, "rgba(11,14,29,.78)");
    text(ret, rx, ry, b.ret >= 0 ? "#69f0a0" : "#ff8a8a");
    text(s.short, cx - textWidth(s.short) / 2, groundY + 2, "#f1f3f5");
  }

  function drawArrow(cx, y, up) {
    const rows = up ? [1, 3, 5, 7, 3, 3] : [3, 3, 7, 5, 3, 1];
    rows.forEach((n, i) => rect(cx - (n >> 1), y + i, n, 1, "#ffffff"));
  }

  function drawStreet(dt) {
    rect(0, groundY, W, 8, "#495057");
    rect(0, groundY + 8, W, 1, "#868e96");
    rect(0, groundY + 9, W, STREET_PX - 9, "#25262b");
    const lane = groundY + 16;
    for (let x = 2; x < W; x += 12) rect(x, lane, 6, 1, "#ced4da");
    for (const c of cars) {
      if (!reducedMotion) c.x += (c.lane ? -1 : 1) * c.speed * dt;
      if (c.x > W + 12) c.x = -12;
      if (c.x < -12) c.x = W + 12;
      const y = groundY + (c.lane ? 19 : 11);
      rect(c.x, y, 10, 3, c.color); rect(c.x + 2, y - 2, 5, 2, c.color); rect(c.x + 3, y - 1, 3, 1, "#a5d8ff");
      rect(c.x + 1, y + 3, 2, 1, "#000"); rect(c.x + 7, y + 3, 2, 1, "#000");
    }
  }

  function frame(t) {
    requestAnimationFrame(frame);
    const dt = Math.min(.1, (t - lastFrame) / 1000);
    if (t - lastFrame < 30) return;
    lastFrame = t;

    const dark = drawSky(t, dt);
    drawSkyline(dark);

    drawStreet(dt);  // before buildings, so their name labels sit on top of the sidewalk

    const list = [...buildings.values()].sort((a, b) => a.seed - b.seed);
    const n = Math.max(1, list.length);
    const w = Math.floor(Math.min(62, Math.max(26, W / (n + 1.4))));
    const gap = (W - n * w) / (n + 1);
    list.forEach((b, i) => {
      if (b.height == null) b.height = b.target;
      const diff = b.target - b.height;
      b.height = Math.abs(diff) < .5 ? b.target : b.height + diff * .08;
      drawBuilding(b, Math.round(gap + i * (w + gap)), w, t, dark);
    });

    const baseY = groundY - midFloors * FLOOR_PX;
    for (let x = 0; x < W; x += 6) rect(x, baseY, 3, 1, "rgba(255,255,255,.55)");
    text("START", 2, baseY - 6, "#ffffff");
    const perFloor = span / Math.max(1, maxFloors - midFloors - 1);
    const scale = `1 FLOOR = ${perFloor.toFixed(perFloor < .1 ? 3 : 2)}%`;
    rect(1, 1, textWidth(scale) + 4, 7, "rgba(11,14,29,.7)");
    text(scale, 3, 2, "#dee2e6");
  }

  function init(el) {
    canvas = el; ctx = canvas.getContext("2d");
    new ResizeObserver(resize).observe(canvas.parentElement);
    resize();
    requestAnimationFrame(frame);
  }

  return { init, setBots, flash, setMarketTime, styleOf: name => STYLES[name] || FALLBACK };
})();
