"""Runs every variant on both windows and saves results; report.py does the selection."""
import json
import multiprocessing as mp
import pickle
import time

from . import grid, harness

BARS = None
WINDOWS = {}


def work(args):
    index, spec = args
    results = {}
    for name, (warm, live) in WINDOWS.items():
        results[name] = harness.run(spec, warm, live)
    return {**spec, "results": results}


def main():
    global BARS, WINDOWS
    BARS = pickle.load(open("data/cache/research_5m.pkl", "rb"))
    WINDOWS = {"train": harness.slice_window(BARS, harness.TRAIN), "target": harness.slice_window(BARS, harness.TARGET)}
    specs = grid.all_specs()
    print(len(specs), "runs", flush=True)
    start = time.time()
    with mp.get_context("fork").Pool(6) as pool:
        out = []
        for i, r in enumerate(pool.imap_unordered(work, enumerate(specs), chunksize=2), 1):
            out.append(r)
            if i % 50 == 0:
                print(i, round(time.time() - start), "s", flush=True)
    json.dump(out, open("data/research_grid.json", "w"))
    print("done", len(out), round(time.time() - start), "s")


if __name__ == "__main__":
    main()
