"""Combines bot orders per ticker, because every bot shares one Alpaca account.

Alpaca can reject opposing orders on one ticker as potential wash trades. Sending one net
order avoids that: bots on opposite sides are matched with each other, and only the
difference goes to the market.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime

from ..models import Decision, Fill, Side


@dataclass
class NetOrder:
    ticker: str
    side: Side | None  # None when buys and sells cancel out exactly
    qty: float
    decisions: list[Decision]


def net_orders(decisions: list[Decision]) -> list[NetOrder]:
    by_ticker: dict[str, list[Decision]] = defaultdict(list)
    for d in decisions:
        by_ticker[d.ticker].append(d)
    orders = []
    for ticker, group in by_ticker.items():
        buys = sum(d.qty for d in group if d.side is Side.BUY)
        sells = sum(d.qty for d in group if d.side is Side.SELL)
        net = round(buys - sells, 6)
        side = Side.BUY if net > 0 else Side.SELL if net < 0 else None
        orders.append(NetOrder(ticker, side, abs(net), group))
    return orders


def allocate(order: NetOrder, filled_qty: float, price: float, ts: datetime, order_id: str) -> list[Fill]:
    """Split a net fill between bots.

    The matched portion always completes. If the market order only part-filled, the bots
    on the net side share what did fill pro rata, so ledgers still match the account.
    """
    buys = sum(d.qty for d in order.decisions if d.side is Side.BUY)
    sells = sum(d.qty for d in order.decisions if d.side is Side.SELL)
    matched = min(buys, sells)
    net_side_total = max(buys, sells)
    ratio = (matched + filled_qty) / net_side_total if net_side_total else 0.0

    fills = []
    for d in order.decisions:
        qty = d.qty * ratio if d.side is order.side else d.qty
        if qty > 1e-9:
            fills.append(Fill(d.bot, d.ticker, d.side, round(qty, 9), price, ts, d.reason, order_id))
    return fills
