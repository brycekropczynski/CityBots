# CityBots results

Replays on real 1-minute Alpaca data, run November 3, 2026. No orders were placed. Each bot
starts with $10,000, and every trade pays an assumed 2 basis points (0.02%) of slippage.

**How to read these:** the current strategies were chosen partly using data inside all of
the periods below, except 2022, so treat the returns as optimistic. Random's figures are for
seed 42 unless noted. Live paper trading has not been tested yet.

## Current strategies

| Bot | Strategy | Stop-loss |
|---|---|---|
| Momentum | Each Friday's close, holds the top 5 tickers by 20-day return, if positive | 15% |
| Mean Reversion | Buys when daily RSI(2) drops under 10, sells on a close above the 5-day average | 15% |
| Inverse FVG | 30-minute candles, gaps of 0.6% or more, buys the first retest of an inverted bearish gap | 3% |
| Random | 10% daily chance of buying each ticker, sells after 10 days | 15% |

Tickers: SPY, QQQ, AAPL, MSFT, NVDA, AMZN, META, GOOGL, TSLA, AMD.

### Past 2 years (Nov 4, 2024 to Nov 3, 2026)

Run ID `replay-20261104-031802`, 501 trading days.

| Bot | Return | Final equity | Trades | Sells that made money | Worst drop from a peak |
|---|---|---|---|---|---|
| Mean Reversion | +34.14% | $13,413.67 | 570 | 73.0% | -13.26% |
| Inverse FVG | +27.70% | $12,770.28 | 839 | 36.3% | -17.21% |
| Momentum | +23.12% | $12,312.39 | 232 | 44.7% | -11.96% |
| Random | +7.88% | $10,787.74 | 486 | 53.1% | -23.48% |
| Hold all 10 tickers (no costs) | +61.77% | | | | |
| SPY alone (no costs) | +35.13% | | | | |

### Past year (Nov 3, 2025 to Nov 3, 2026)

Run ID `replay-20261104-031501`, 252 trading days.

| Bot | Return | Final equity | Trades | Sells that made money | Worst drop from a peak |
|---|---|---|---|---|---|
| Mean Reversion | +12.44% | $11,244.35 | 306 | 71.1% | -4.87% |
| Inverse FVG | +11.88% | $11,188.10 | 409 | 36.8% | -9.86% |
| Momentum | +3.83% | $10,382.76 | 116 | 33.9% | -11.03% |
| Random | +2.19% | $10,218.63 | 248 | 49.6% | -9.56% |
| Hold all 10 tickers (no costs) | +11.00% | | | | |
| SPY alone (no costs) | +11.22% | | | | |

### Past 6 months (May 4 to Nov 3, 2026)

Run ID `replay-20261104-031125`, 128 trading days.

| Bot | Return | Final equity | Trades |
|---|---|---|---|
| Inverse FVG | +8.13% | $10,813.50 | 177 |
| Mean Reversion | +6.61% | $10,661.29 | 150 |
| Random | +3.11% | $10,311.15 | 127 |
| Momentum | -4.19% | $9,580.95 | 62 |
| Hold all 10 tickers (no costs) | +6.16% | | |

## Sensitivity checks (last 6 months)

**Momentum by rebalance day:** only Monday was positive, so its result depends heavily on
the weekday.

| Rebalance day | Last 6 months | May 2025 to May 2026 |
|---|---|---|
| Monday | +2.08% | +22.09% |
| Tuesday | -1.43% | +25.44% |
| Wednesday | -2.42% | +17.63% |
| Thursday | -3.65% | +26.09% |
| Friday (current) | -4.19% | +17.28% |

**Random across seeds:** over 30 other seeds, the median was +0.65%, the range was -6.75% to
+11.21%, and 15 of 30 were positive.

**Higher slippage** on the variants as first tested:

| Bot | 2 bps | 5 bps | 10 bps |
|---|---|---|---|
| Mean Reversion | +6.61% | +6.14% | +5.35% |
| Inverse FVG | +8.14% | +7.62% | +6.76% |
| Momentum (every 5th trading day) | +1.83% | +1.61% | +1.23% |

## Untouched test: 2022

These variants were frozen before this test, and holding all 10 tickers lost 43.29% that
year. Momentum here rebalanced every 5th trading day, not on Fridays.

| Bot | 2022 return |
|---|---|
| Mean Reversion | +5.78% |
| Inverse FVG | -10.74% |
| Momentum | -18.16% |
| Random (median of 30 seeds, none positive) | -24.40% |

## Original strategies, for comparison

| Bot | Last 6 months | May 2025 to May 2026 |
|---|---|---|
| Random | -4.91% | -8.07% |
| Momentum | -16.22% | -27.29% |
| Mean Reversion | -22.89% | -37.74% |
| Inverse FVG | -36.06% | -50.02% |

These traded on 1-minute bars, and slippage on thousands of trades caused most of the losses.

## Limits

- Slippage is an assumption, not a measured cost, and fills are simulated at the next bar's
  open.
- The tickers are mostly large US tech names that are well known today, which flatters results.
- Past results don't predict future ones.

## Position size test: past 2 years

Same strategies with a larger cap per position, using `research/monthly.py`. These figures
are in-sample, and 100% means one position at a time. Worst drop uses end-of-day equity.

| Bot | Position cap | Return | Worst drop | Average month | Best month | Worst month | Positive months |
|---|---|---|---|---|---|---|---|
| Mean Reversion | 10% (current) | +34.14% | -11.51% | +1.20% | +6.66% | -3.98% | 20/25 |
| Mean Reversion | 20% | +62.21% | -13.74% | +1.99% | +6.12% | -5.67% | 21/25 |
| Mean Reversion | 50% | +93.54% | -17.98% | +2.77% | +11.62% | -10.41% | 19/25 |
| Inverse FVG | 10% (current) | +27.70% | -16.55% | +1.05% | +10.72% | -4.34% | 12/25 |
| Inverse FVG | 100% | +129.01% | -34.92% | +3.92% | +31.86% | -14.68% | 15/25 |
| Momentum | 10% (current) | +23.12% | -11.82% | +0.92% | +11.44% | -6.54% | 13/25 |
| Momentum | 50% | +83.92% | -27.04% | +3.11% | +43.69% | -19.59% | 14/25 |
| Random | 10% (current) | +7.88% | -22.73% | +0.38% | +8.30% | -6.56% | 11/25 |

No bot reached +50% in any month, at any of the five position sizes tested. Even holding only
the best ticker each month with perfect hindsight reached +50% in just 2 of 24 months, and
averaged +20.27%.

## Past 4 years, by position size (Nov 3, 2022 to Nov 3, 2026)

Real 1-minute data with 2 bps slippage, using `research/monthly.py`. This window starts near a
market low, and holding all 10 tickers returned +386.89% before costs (SPY alone +113.91%).
100% means one position at a time.

**4-year return**

| Bot | 10% | 20% | 33% | 50% | 100% |
|---|---|---|---|---|---|
| Mean Reversion | +76.11% | +172.00% | +213.07% | +247.29% | +113.40% |
| Inverse FVG | +72.16% | +104.37% | +209.13% | +239.52% | +171.33% |
| Momentum (Friday) | +81.77% | +143.57% | +197.49% | +153.00% | +37.96% |
| Random, seed 42 | +125.19% | +254.32% | +336.65% | +634.63% | +174.40% |
| Random, median of 30 other seeds | +103.79% | not run | +219.87% | +241.00% | not run |

**Worst drop from a peak, 4 years (end of day)**

| Bot | 10% | 20% | 33% | 50% | 100% |
|---|---|---|---|---|---|
| Mean Reversion | -11.51% | -13.74% | -16.17% | -18.22% | -28.59% |
| Inverse FVG | -16.62% | -22.40% | -24.01% | -42.08% | -36.07% |
| Momentum (Friday) | -14.07% | -22.20% | -23.43% | -34.78% | -31.49% |
| Random, seed 42 | -12.32% | -17.27% | -20.80% | -15.01% | -46.33% |

**2022 only, a falling market** (`research/seeds_4yr.py`, 5-minute bars). Holding all 10
tickers lost 43.29%.

| Bot | 10% | 20% | 33% | 50% | 100% |
|---|---|---|---|---|---|
| Mean Reversion | +6.47% | +2.92% | +6.04% | +2.72% | -14.99% |
| Inverse FVG | -11.04% | -23.96% | -39.68% | -43.15% | -61.44% |
| Momentum (Friday) | -18.48% | -31.46% | -32.44% | -25.65% | -42.06% |
| Random, median of 30 seeds | -25.40% | -36.02% | -36.15% | -43.57% | -47.52% |

**Random across 30 seeds, 4 years:** all 30 were positive at each size tested. The range was
+57.70% to +161.77% at 10%, and +53.06% to +496.79% at 50%. Seed 42's +634.63% at 50% is above
every one of those 30 seeds, so it is a lucky draw.

No bot reached +50% in any of its 49 months, at any size. With perfect hindsight, holding only
the best ticker each month reached +50% in 2 of 48 months and averaged +19.40%.

Positive months at the current 10% cap: Mean Reversion 38/49, Random (seed 42) 33/49,
Momentum 29/49, Inverse FVG 29/49.

## Past 4 years, each ticker vs the bots (Nov 3, 2022 to Nov 3, 2026)

Tickers are buy and hold with no costs, on dividend- and split-adjusted prices. Bots use the
current 10% position cap and 2 bps slippage. Worst drop is measured at end of day.

| Rank | Holding | 4-year return | $10,000 becomes | Worst drop from a peak |
|---|---|---|---|---|
| 1 | NVDA | +1,488.92% | $158,892 | -36.94% |
| 2 | AMD | +733.87% | $83,387 | -62.99% |
| 3 | META | +595.94% | $69,594 | -34.17% |
| 4 | GOOGL | +227.16% | $32,716 | -30.61% |
| 5 | AMZN | +171.16% | $27,116 | -30.89% |
| 6 | QQQ | +166.81% | $26,681 | -22.74% |
| 7 | MSFT | +144.49% | $24,449 | -34.58% |
| 8 | AAPL | +138.05% | $23,805 | -33.25% |
| 9 | Random bot (seed 42) | +125.19% | $22,519 | -12.32% |
| 10 | SPY | +113.91% | $21,391 | -18.71% |
| 11 | TSLA | +88.54% | $18,854 | -53.82% |
| 12 | Momentum bot | +81.77% | $18,177 | -14.07% |
| 13 | Mean Reversion bot | +76.11% | $17,611 | -11.51% |
| 14 | Inverse FVG bot | +72.16% | $17,216 | -16.62% |

Holding all 10 equally returned +386.89%, with a worst drop of -28.44%.

**Correction:** this file and an earlier chat answer first gave hold-all as +353.06% and SPY as
+105.78%. The 4-year price cache was stitched together out of date order, and that calculation
read it unsorted, so it started on Jan 3, 2023. `research/monthly.py` now sorts first. Bot
results were not affected, because the replay feed sorts bars by time, and the perfect-hindsight
figure is unchanged when recomputed on sorted data.
