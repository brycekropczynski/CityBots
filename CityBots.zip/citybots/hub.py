"""Fan-out between the engine and connected browsers. A slow browser can't stall trading."""
from __future__ import annotations

import asyncio
from collections import deque

MAX_QUEUE = 500


class Hub:
    def __init__(self):
        self.clients: set[asyncio.Queue] = set()
        self.status: dict = {"state": "starting", "message": ""}
        self.bots: list[dict] = []
        self.recent_trades: deque[dict] = deque(maxlen=50)

    def snapshot(self) -> dict:
        return {"type": "snapshot", "status": self.status, "bots": self.bots,
                "trades": list(self.recent_trades)}

    def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(MAX_QUEUE)
        self.clients.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        self.clients.discard(queue)

    def _publish(self, message: dict) -> None:
        for queue in self.clients:
            if queue.full():
                queue.get_nowait()  # drop the oldest message for this client only
            queue.put_nowait(message)

    def update_status(self, **fields) -> None:
        self.status = {**self.status, **fields}
        self._publish({"type": "status", "status": self.status})

    def publish_trade(self, trade: dict) -> None:
        self.recent_trades.append(trade)
        self._publish({"type": "trade", "trade": trade})

    def publish_equity(self, bots: list[dict], **status) -> None:
        self.bots = bots
        self.status = {**self.status, **status}
        self._publish({"type": "equity", "bots": bots, "status": self.status})
