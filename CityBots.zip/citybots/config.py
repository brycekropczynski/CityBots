"""Settings, loaded from .env. API keys never leave this process except to Alpaca."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from urllib.parse import urlparse

from dotenv import load_dotenv

DEFAULT_TICKERS = ("SPY", "QQQ", "AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "TSLA", "AMD")
PAPER_HOST = "paper-api.alpaca.markets"


class ConfigError(Exception):
    """A setup problem the user can fix; shown without a traceback."""


@dataclass(frozen=True)
class RiskConfig:
    starting_cash: float = 10_000.0
    max_position_pct: float = 0.10
    stop_loss_pct: float = 0.02
    reentry_cooldown_bars: int = 5  # bars a bot sits out a ticker after being stopped out
    min_order_notional: float = 5.0


@dataclass(frozen=True)
class Settings:
    api_key: str = field(default="", repr=False)
    secret_key: str = field(default="", repr=False)
    tickers: tuple[str, ...] = DEFAULT_TICKERS
    db_path: str = "data/citybots.sqlite"
    cache_dir: str = "data/cache"
    risk: RiskConfig = field(default_factory=RiskConfig)
    poll_seconds: float = 10.0
    slippage_bps: float = 2.0

    def require_keys(self) -> None:
        if not self.api_key or not self.secret_key:
            raise ConfigError(
                "Alpaca keys are missing. Copy .env.example to .env and add your paper trading "
                "keys, or use `replay --synthetic` to run without them."
            )


def assert_paper_endpoint(url: str | None) -> None:
    """Refuse to run against anything except Alpaca's paper trading host."""
    if url and urlparse(url).hostname != PAPER_HOST:
        raise ConfigError(f"ALPACA_BASE_URL must point at {PAPER_HOST}; this simulator is paper-only.")


def load_settings() -> Settings:
    load_dotenv()
    assert_paper_endpoint(os.getenv("ALPACA_BASE_URL"))
    raw = os.getenv("CITYBOTS_TICKERS", "")
    tickers = tuple(t.strip().upper() for t in raw.split(",") if t.strip()) or DEFAULT_TICKERS
    return Settings(
        api_key=os.getenv("ALPACA_API_KEY", ""),
        secret_key=os.getenv("ALPACA_SECRET_KEY", ""),
        tickers=tickers,
        db_path=os.getenv("CITYBOTS_DB", "data/citybots.sqlite"),
    )
