"""Sends netted market orders to Alpaca's paper API and reports confirmed fills."""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.trading.requests import MarketOrderRequest

from ..config import ConfigError, Settings
from ..models import Decision, Fill, MarketEvent, Side
from .netting import NetOrder, allocate, net_orders

log = logging.getLogger(__name__)
MIN_ORDER_NOTIONAL = 1.0  # Alpaca's minimum for fractional orders
TERMINAL = {"filled", "canceled", "expired", "rejected", "done_for_day"}


def make_trading_client(settings: Settings) -> TradingClient:
    return TradingClient(settings.api_key, settings.secret_key, paper=True)  # always paper


def preflight(client, bots) -> list[str]:
    """Stops on an unusable account; returns warnings where it doesn't match the ledgers."""
    try:
        account = client.get_account()
        held = {p.symbol: float(p.qty) for p in client.get_all_positions()}
    except Exception as exc:
        raise ConfigError(f"Could not reach your Alpaca paper account: {exc}") from exc

    needed = sum(b.risk.starting_cash for b in bots)
    if float(account.equity) < needed:
        raise ConfigError(f"Paper account equity is {account.equity}; {needed:,.0f} is needed to fund all bots.")
    if account.trading_blocked:
        raise ConfigError("Alpaca reports trading is blocked on this paper account.")

    ledger: dict[str, float] = {}
    for bot in bots:
        for ticker, pos in bot.positions.items():
            ledger[ticker] = ledger.get(ticker, 0.0) + pos.qty
    return [
        f"{t}: bots hold {ledger.get(t, 0.0):g}, the account holds {held.get(t, 0.0):g}"
        for t in sorted(ledger.keys() | held.keys())
        if abs(ledger.get(t, 0.0) - held.get(t, 0.0)) > 1e-4
    ]


class AlpacaBroker:
    def __init__(self, client, fill_timeout: float = 8.0, poll_interval: float = 0.5, sleep=asyncio.sleep):
        self.client = client
        self.fill_timeout = fill_timeout
        self.poll_interval = poll_interval
        self.sleep = sleep
        self.deferred: dict[tuple[str, str], Decision] = {}

    async def on_event(self, event: MarketEvent) -> list[Fill]:
        """Sends orders held since the last close. Everything else resolves in execute()."""
        if event.closing or not self.deferred:
            return []
        decisions = list(self.deferred.values())
        self.deferred.clear()
        return await self.execute(decisions, event)

    async def execute(self, decisions: list[Decision], event: MarketEvent) -> list[Fill]:
        if event.closing:
            # Matches replay, where a signal on the last bar fills at the next open.
            self.deferred.update({(d.bot, d.ticker): d for d in decisions})
            return []
        results = await asyncio.gather(*(self._execute(o, event) for o in net_orders(decisions)))
        return [fill for fills in results for fill in fills]

    async def _execute(self, order: NetOrder, event: MarketEvent) -> list[Fill]:
        reference = event.prices.get(order.ticker, 0.0)
        # Exact matches, and leftovers too small to send, settle between bots at the last price.
        if order.side is None or order.qty * reference < MIN_ORDER_NOTIONAL:
            return allocate(order, order.qty, reference, event.ts, "internal")
        try:
            filled_qty, price, ts, order_id = await self._submit_and_wait(order)
        except Exception:
            log.exception("Order failed: %s %s %s", order.side.value, order.qty, order.ticker)
            filled_qty, price, ts, order_id = 0.0, reference, event.ts, "failed"
        return allocate(order, filled_qty, price or reference, ts or event.ts, order_id)

    async def _submit_and_wait(self, order: NetOrder):
        request = MarketOrderRequest(
            symbol=order.ticker,
            qty=order.qty,
            side=OrderSide.BUY if order.side is Side.BUY else OrderSide.SELL,
            time_in_force=TimeInForce.DAY,  # required for fractional orders
            client_order_id=f"citybots-{uuid.uuid4().hex[:20]}",
        )
        placed = await asyncio.to_thread(self.client.submit_order, request)
        order_id = str(placed.id)

        current, waited = placed, 0.0
        while _status(current) not in TERMINAL and waited < self.fill_timeout:
            await self.sleep(self.poll_interval)
            waited += self.poll_interval
            current = await asyncio.to_thread(self.client.get_order_by_id, order_id)

        if _status(current) not in TERMINAL:
            log.warning("Cancelling unfilled order %s for %s", order_id, order.ticker)
            try:
                await asyncio.to_thread(self.client.cancel_order_by_id, order_id)
            except Exception:
                log.warning("Cancel failed for order %s; it may have just filled", order_id)
            await self.sleep(self.poll_interval)
            current = await asyncio.to_thread(self.client.get_order_by_id, order_id)

        filled = float(current.filled_qty or 0)
        price = float(current.filled_avg_price) if current.filled_avg_price else None
        ts = current.filled_at or datetime.now(timezone.utc)
        if _status(current) != "filled":
            log.warning("Order %s for %s ended %s with %s filled", order_id, order.ticker, _status(current), filled)
        return filled, price, ts, order_id


def _status(order) -> str:
    return getattr(order.status, "value", str(order.status))
