from datetime import datetime, timedelta, timezone

import pytest

from citybots.models import Bar

T0 = datetime(2026, 10, 5, 14, 0, tzinfo=timezone.utc)


def bar(i=0, close=100.0, open_=None, high=None, low=None, volume=1000.0, ticker="AAA"):
    open_ = close if open_ is None else open_
    return Bar(ticker, T0 + timedelta(minutes=i), open_, max(open_, close) if high is None else high,
               min(open_, close) if low is None else low, close, volume)


@pytest.fixture
def make_bar():
    return bar
