"""The trading loop. Live and replay both run through step(); only the feed and broker differ."""
from __future__ import annotations

import asyncio
import logging
import time

from .config import ConfigError
from .hub import Hub
from .models import Fill, MarketEvent
from .storage import Store

log = logging.getLogger(__name__)
PUBLISH_INTERVAL = 0.05  # caps browser updates at very high replay speeds


class Engine:
    def __init__(self, bots, feed, broker, store: Store, hub: Hub, run_id: str, mode: str):
        self.bots = bots
        self.by_name = {b.name: b for b in bots}
        self.feed = feed
        self.broker = broker
        self.store = store
        self.hub = hub
        self.run_id = run_id
        self.mode = mode
        self.finished = asyncio.Event()
        self._last_publish = 0.0
        self.feed.on_status = hub.update_status

    async def run(self) -> None:
        try:
            for bar in await self.feed.warmup():
                for bot in self.bots:
                    bot.warm_up(bar)
            self.publish_equity(force=True)
            event = None
            async for event in self.feed.events():
                await self.step(event)
            self.publish_equity(event, force=True)
            self.hub.update_status(state="finished", message="Replay complete", progress=1.0)
        except asyncio.CancelledError:
            raise
        except ConfigError as exc:
            log.error("%s", exc)
            self.hub.update_status(state="error", message=str(exc))
        except Exception as exc:
            log.exception("Engine stopped")
            self.hub.update_status(state="error", message=f"Engine stopped: {exc}")
        finally:
            self.finished.set()

    async def step(self, event: MarketEvent) -> None:
        # 1. Orders queued last step fill now (replay only).
        self.record(await self.broker.on_event(event))

        # 2. Revalue every bot, then exit anything through its stop. These fills land
        #    before signals, so a stopped-out position can't also receive a sell signal.
        for bot in self.bots:
            bot.update_marks(event.prices)
        stops = [d for bot in self.bots for d in bot.check_stops(event.lows)]
        if stops:
            self.record(await self.broker.execute(stops, event))

        # 3. Strategies act on newly closed bars.
        decisions = []
        for bot in self.bots:
            bot.begin_round()
            for bar in event.closed_bars:
                decision = bot.on_bar(bar)
                if decision:
                    decisions.append(decision)
        if decisions:
            self.record(await self.broker.execute(decisions, event))

        self.store.log_equity(self.run_id, event.ts, [(b.name, b.equity, b.cash) for b in self.bots])
        self.publish_equity(event)

    def record(self, fills: list[Fill]) -> None:
        if not fills:
            return
        for fill in fills:
            self.by_name[fill.bot].apply_fill(fill)
        self.store.log_trades(self.run_id, self.mode, fills)
        for fill in fills:
            self.hub.publish_trade({
                "bot": fill.bot,
                "ticker": fill.ticker,
                "side": fill.side.value,
                "price": round(fill.price, 4),
                "qty": round(fill.qty, 4),
                "time": fill.ts.isoformat(),
                "reason": fill.reason,
                "pnl": None if fill.realized_pnl is None else round(fill.realized_pnl, 2),
            })

    def publish_equity(self, event: MarketEvent | None = None, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_publish < PUBLISH_INTERVAL:
            return
        self._last_publish = now
        status = {}
        if event is not None:
            status["sim_time"] = event.ts.isoformat()
            if event.progress is not None:
                status["progress"] = event.progress
        self.hub.publish_equity(self.leaderboard(), **status)

    def leaderboard(self) -> list[dict]:
        rows = [
            {
                "name": b.name,
                "equity": round(b.equity, 2),
                "cash": round(b.cash, 2),
                "return_pct": round(b.return_pct, 4),
                "trades": b.trade_count,
                "positions": len(b.positions),
            }
            for b in self.bots
        ]
        return sorted(rows, key=lambda r: r["return_pct"], reverse=True)
