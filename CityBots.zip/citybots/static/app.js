// Connects to the server and keeps the page in sync. Every value is written with
// textContent, so nothing from the stream is ever parsed as HTML.
const $ = id => document.getElementById(id);
const MAX_TICKER_ITEMS = 30;
const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const clockFmt = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
const timeFmt = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });

let connected = false;
let lastStatus = {};
let pendingTrades = [];

function el(tag, className, content) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content != null) node.textContent = content;
  return node;
}

function renderStatus(s) {
  lastStatus = s;
  const mode = $("mode");
  mode.textContent = s.mode === "replay" ? `REPLAY ${s.speed ? s.speed + "x" : "MAX SPEED"}` : s.mode === "live" ? "LIVE PAPER" : "…";
  mode.classList.toggle("live", s.mode === "live");
  $("source").hidden = s.source !== "synthetic";

  if (s.sim_time) {
    $("clock").textContent = clockFmt.format(new Date(s.sim_time)) + " ET";
    City.setMarketTime(s.state === "waiting" ? null : s.sim_time);
  }
  if (s.state === "waiting") City.setMarketTime(null);

  const progress = $("progress");
  progress.hidden = s.progress == null;
  if (s.progress != null) {
    const pct = Math.round(s.progress * 100);
    progress.firstElementChild.style.width = pct + "%";
    progress.setAttribute("aria-valuenow", pct);
  }

  const message = $("message");
  message.classList.toggle("error", s.state === "error" || !connected);
  message.textContent = connected ? (s.message || "") : "Connection lost, reconnecting";
}

function renderBoard(bots) {
  const rows = bots.map((b, i) => {
    const tr = el("tr");
    const name = el("td");
    const swatch = el("span", "swatch");
    swatch.style.background = City.styleOf(b.name).body;
    name.append(swatch, b.name);
    const ret = el("td", `n ${b.return_pct >= 0 ? "up" : "down"}`, `${b.return_pct >= 0 ? "+" : ""}${b.return_pct.toFixed(2)}%`);
    tr.append(el("td", "", i + 1), name, ret, el("td", "n", money.format(b.equity)), el("td", "n", b.trades), el("td", "n", b.positions));
    return tr;
  });
  $("board").replaceChildren(...rows);
}

function tickerItem(t) {
  const li = el("li");
  const up = t.side === "buy";
  li.append(
    el("span", "dim", timeFmt.format(new Date(t.time)) + " "),
    `${t.bot} `,
    el("span", up ? "up" : "down", `${up ? "▲ BUY" : "▼ SELL"} `),
    `${t.qty} ${t.ticker} @ ${t.price.toFixed(2)}`,
  );
  if (t.pnl != null) li.append(el("span", t.pnl >= 0 ? "up" : "down", ` ${t.pnl >= 0 ? "+" : "-"}${money.format(Math.abs(t.pnl))}`));
  if (t.reason === "stop-loss") li.append(el("span", "dim", " stop"));
  return li;
}

function flushTrades() {
  requestAnimationFrame(flushTrades);
  if (!pendingTrades.length) return;
  const ticker = $("ticker");
  ticker.prepend(...pendingTrades.slice(-MAX_TICKER_ITEMS).reverse().map(tickerItem));
  while (ticker.children.length > MAX_TICKER_ITEMS) ticker.lastElementChild.remove();
  pendingTrades = [];
}

function handle(msg) {
  if (msg.type === "snapshot") {
    City.setBots(msg.bots);
    renderBoard(msg.bots);
    renderStatus(msg.status);
    $("ticker").replaceChildren(...msg.trades.slice(-MAX_TICKER_ITEMS).reverse().map(tickerItem));
  } else if (msg.type === "equity") {
    City.setBots(msg.bots);
    renderBoard(msg.bots);
    renderStatus(msg.status);
  } else if (msg.type === "status") {
    renderStatus(msg.status);
  } else if (msg.type === "trade") {
    City.flash(msg.trade.bot, msg.trade.side);
    pendingTrades.push(msg.trade);
  }
}

function connect(delay = 500) {
  const scheme = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${scheme}://${location.host}/ws`);
  ws.onopen = () => { connected = true; delay = 500; renderStatus(lastStatus); };
  ws.onmessage = e => handle(JSON.parse(e.data));
  ws.onclose = () => {
    connected = false;
    renderStatus(lastStatus);
    setTimeout(() => connect(Math.min(delay * 2, 8000)), delay);
  };
}

City.init($("city"));
requestAnimationFrame(flushTrades);
connect();
