"""Replay fills. Signals fill at the next bar's open, so no bot trades on a price it
couldn't have got. A stop fills at its level, or at the open if the bar gapped through it."""
from __future__ import annotations

from ..models import Decision, Fill, MarketEvent, Side


class SimBroker:
    def __init__(self, slippage_bps: float = 2.0):
        self.slippage = slippage_bps / 10_000
        self.pending: dict[tuple[str, str], Decision] = {}
        self._next_id = 0

    def _fill(self, d: Decision, base_price: float, event: MarketEvent) -> Fill:
        sign = 1 if d.side is Side.BUY else -1
        self._next_id += 1
        return Fill(d.bot, d.ticker, d.side, d.qty, base_price * (1 + sign * self.slippage),
                    event.ts, d.reason, f"sim-{self._next_id}")

    async def on_event(self, event: MarketEvent) -> list[Fill]:
        fills = []
        for key, d in list(self.pending.items()):
            if d.ticker in event.opens:
                fills.append(self._fill(d, event.opens[d.ticker], event))
                del self.pending[key]
        return fills

    async def execute(self, decisions: list[Decision], event: MarketEvent) -> list[Fill]:
        fills = []
        for d in decisions:
            if d.stop_price is None:
                self.pending[(d.bot, d.ticker)] = d
            else:
                base = min(event.opens.get(d.ticker, d.stop_price), d.stop_price)
                fills.append(self._fill(d, base, event))
        return fills
