"""Variants for each bot family. The grid is fixed before any results are seen."""
from itertools import product


def spec(family, cls, stop, **args):
    tag = ",".join(f"{k}={v}" for k, v in args.items() if k != "seed")
    return {"family": family, "cls": cls, "stop": stop, "args": args, "id": f"{cls}({tag},stop={stop})"}


def momentum():
    out = []
    for tf, (entry, exit_), regime, stop in product((60, 390), ((20, 10), (55, 20), (10, 5)), (0, 50), (0.05, 0.08)):
        out.append(spec("Momentum", "Donchian", stop, tf=tf, entry=entry, exit=exit_, regime=regime))
    for lookback, top, every, regime, stop in product((20, 60), (3, 5), (5, 20), (0, 50), (0.08, 0.15)):
        out.append(spec("Momentum", "Rotation", stop, lookback=lookback, top=top, every=every, regime=regime))
    for minutes, regime, stop in product((15, 30, 60), (0, 50), (0.01, 0.02)):
        out.append(spec("Momentum", "OpeningRange", stop, minutes=minutes, regime=regime))
    return out


def mean_reversion():
    out = []
    for tf, std, trend, stop in product((60, 120, 390), (1.5, 2.0, 2.5), (0, 50, 100), (0.05, 0.08)):
        out.append(spec("Mean Reversion", "Bands", stop, tf=tf, period=20, entry_std=std, trend=trend))
    for entry, trend, stop in product((5, 10, 20), (0, 50, 100), (0.05, 0.08, 0.15)):
        out.append(spec("Mean Reversion", "RSI2", stop, entry=entry, trend=trend))
    return out


def inverse_fvg():
    out = []
    for tf, gap, trend, hold, stop in product((30, 60, 120, 390), (0.001, 0.003, 0.006), (0, 50), (0, 20), (0.03, 0.08)):
        out.append(spec("Inverse FVG", "SlowIFVG", stop, tf=tf, min_gap=gap, trend=trend, max_hold=hold))
    return out


def random_hold():
    return [spec("Random", "RandomHold", stop, prob=p, hold=h, seed=seed)
            for p, h, stop in product((0.02, 0.05, 0.1), (10, 20, 40), (0.08, 0.15))
            for seed in range(5)]


def all_specs():
    return momentum() + mean_reversion() + inverse_fvg() + random_hold()
