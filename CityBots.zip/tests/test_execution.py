import asyncio
from types import SimpleNamespace as NS

import pytest
from conftest import T0

from citybots.config import ConfigError, assert_paper_endpoint
from citybots.bots import MomentumBot
from citybots.execution.alpaca_broker import AlpacaBroker, preflight
from citybots.execution.netting import allocate, net_orders
from citybots.execution.sim_broker import SimBroker
from citybots.models import Decision, Fill, MarketEvent, Side


def d(bot, side, qty, ticker="AAA", stop=None):
    return Decision(bot, ticker, side, qty, "test", stop_price=stop)


def event(price=100.0, open_=None, low=None):
    return MarketEvent(T0, {"AAA": price}, lows={"AAA": low or price}, opens={"AAA": open_ or price})


def test_opposing_orders_net_to_the_difference():
    order = net_orders([d("a", Side.BUY, 5), d("b", Side.SELL, 3)])[0]
    assert (order.side, order.qty) == (Side.BUY, 2)


def test_full_net_fill_gives_every_bot_its_quantity():
    order = net_orders([d("a", Side.BUY, 5), d("b", Side.SELL, 3)])[0]
    fills = {f.bot: f for f in allocate(order, 2, 101.0, T0, "x")}
    assert fills["a"].qty == 5 and fills["b"].qty == 3
    assert fills["a"].price == fills["b"].price == 101.0


def test_partial_fill_keeps_match_and_prorates_net_side():
    order = net_orders([d("a", Side.BUY, 6), d("b", Side.BUY, 2), d("c", Side.SELL, 4)])[0]
    assert order.qty == 4
    fills = {f.bot: f.qty for f in allocate(order, 2, 100.0, T0, "x")}
    assert fills["c"] == 4
    assert fills["a"] == pytest.approx(4.5) and fills["b"] == pytest.approx(1.5)
    # Bots' net change equals what the account actually traded.
    assert fills["a"] + fills["b"] - fills["c"] == pytest.approx(2)


def test_rejected_order_leaves_lone_bot_with_no_fill():
    order = net_orders([d("a", Side.BUY, 5)])[0]
    assert allocate(order, 0.0, 100.0, T0, "failed") == []


def test_sim_signal_fills_at_next_open_with_slippage():
    async def go():
        broker = SimBroker(slippage_bps=10)
        assert await broker.execute([d("a", Side.BUY, 1)], event(100)) == []
        fills = await broker.on_event(event(105, open_=102))
        assert fills[0].price == pytest.approx(102 * 1.001)
        assert await broker.on_event(event(106)) == []
    asyncio.run(go())


def test_sim_stop_fills_at_level_or_gap_open():
    async def go():
        broker = SimBroker(slippage_bps=0)
        stop = d("a", Side.SELL, 1, stop=98.0)
        at_level = await broker.execute([stop], event(97, open_=99, low=97))
        gapped = await broker.execute([stop], event(95, open_=95, low=94))
        assert at_level[0].price == 98.0 and gapped[0].price == 95.0
    asyncio.run(go())


class FakeClient:
    def __init__(self, final):
        self.final = final
        self.requests = []
        self.cancelled = []

    def submit_order(self, request):
        self.requests.append(request)
        return NS(id="order-1", status=NS(value="accepted"), filled_qty=None, filled_avg_price=None, filled_at=None)

    def get_order_by_id(self, order_id):
        return self.final

    def cancel_order_by_id(self, order_id):
        self.cancelled.append(order_id)


async def no_sleep(_):
    return None


def test_alpaca_broker_sends_one_net_order_and_uses_real_fill_price():
    client = FakeClient(NS(status=NS(value="filled"), filled_qty="2", filled_avg_price="101.5", filled_at=T0))
    broker = AlpacaBroker(client, sleep=no_sleep)
    fills = asyncio.run(broker.execute([d("a", Side.BUY, 5), d("b", Side.SELL, 3)], event(100)))
    assert len(client.requests) == 1
    assert client.requests[0].qty == 2 and client.requests[0].side.value == "buy"
    assert {f.bot: (f.qty, f.price) for f in fills} == {"a": (5, 101.5), "b": (3, 101.5)}


def test_closing_orders_wait_for_next_open_without_duplicates():
    client = FakeClient(NS(status=NS(value="filled"), filled_qty="5", filled_avg_price="102", filled_at=T0))
    broker = AlpacaBroker(client, sleep=no_sleep)
    closing = MarketEvent(T0, {"AAA": 100.0}, closing=True)

    async def go():
        assert await broker.execute([d("a", Side.BUY, 5), d("a", Side.BUY, 5)], closing) == []
        assert client.requests == []
        assert await broker.on_event(closing) == []
        fills = await broker.on_event(event(101))
        assert await broker.on_event(event(101)) == []
        return fills

    fills = asyncio.run(go())
    assert len(client.requests) == 1 and client.requests[0].qty == 5
    assert fills[0].price == 102


def test_alpaca_broker_cancels_unfilled_order():
    client = FakeClient(NS(status=NS(value="new"), filled_qty="0", filled_avg_price=None, filled_at=None))
    broker = AlpacaBroker(client, fill_timeout=1.0, sleep=no_sleep)
    assert asyncio.run(broker.execute([d("a", Side.BUY, 5)], event(100))) == []
    assert client.cancelled == ["order-1"]


def test_alpaca_broker_survives_rejection():
    class Rejecting(FakeClient):
        def submit_order(self, request):
            raise RuntimeError("rejected")
    broker = AlpacaBroker(Rejecting(None), sleep=no_sleep)
    assert asyncio.run(broker.execute([d("a", Side.BUY, 5)], event(100))) == []


def test_exact_cross_sends_no_order():
    client = FakeClient(None)
    fills = asyncio.run(AlpacaBroker(client, sleep=no_sleep).execute([d("a", Side.BUY, 3), d("b", Side.SELL, 3)], event(100)))
    assert client.requests == [] and len(fills) == 2 and {f.price for f in fills} == {100}


class Account:
    def __init__(self, equity="100000", positions=()):
        self.account = NS(equity=equity, trading_blocked=False)
        self.positions = positions

    def get_account(self):
        return self.account

    def get_all_positions(self):
        return list(self.positions)


def test_preflight_rejects_underfunded_account():
    with pytest.raises(ConfigError):
        preflight(Account(equity="5000"), [MomentumBot() for _ in range(4)])


def test_preflight_reports_position_mismatch():
    bot = MomentumBot()
    bot.apply_fill(Fill(bot.name, "AAA", Side.BUY, 1.0, 100.0, T0, "x"))
    warnings = preflight(Account(positions=[NS(symbol="BBB", qty="3")]), [bot])
    assert len(warnings) == 2


def test_only_paper_endpoint_is_allowed():
    assert_paper_endpoint("https://paper-api.alpaca.markets")
    assert_paper_endpoint(None)
    with pytest.raises(ConfigError):
        assert_paper_endpoint("https://api.alpaca.markets")
