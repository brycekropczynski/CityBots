"""Selection uses train results only: best train Sharpe per family with at least 30 fills."""
import json
import pickle
from collections import defaultdict
from statistics import fmean, median

from . import harness

rows = json.load(open("data/research_grid.json"))
FAMILIES = ["Momentum", "Mean Reversion", "Inverse FVG", "Random"]


def buy_hold(window):
    _, live = harness.slice_window(pickle.load(open("data/cache/research_5m.pkl", "rb")), window)
    first, last = {}, {}
    for b in live:
        first.setdefault(b.ticker, b.open)
        last[b.ticker] = b.close
    return {t: round((last[t] / first[t] - 1) * 100, 1) for t in first}


for name, window in (("train", harness.TRAIN), ("target", harness.TARGET)):
    bh = buy_hold(window)
    print(f"buy & hold {name}: equal-weight {fmean(bh.values()):.2f}%  SPY {bh['SPY']}%")

fields = ("return", "sharpe", "max_dd", "fills", "win", "exposure")


def line(r, w):
    m = r[w]
    return " ".join(f"{k}={m[k]}" for k in fields)


selected = {}
for fam in FAMILIES:
    groups = defaultdict(list)
    for r in rows:
        if r["family"] == fam:
            groups[r["id"]].append(r["results"])
    scored = []
    for id_, runs in groups.items():
        if fmean(x["train"]["fills"] for x in runs) >= 30:
            scored.append((fmean(x["train"]["sharpe"] for x in runs), id_))
    scored.sort(reverse=True)
    selected[fam] = scored[0][1]
    all_target = [fmean(x["target"]["return"] for x in runs) for runs in groups.values()]
    all_train = [fmean(x["train"]["return"] for x in runs) for runs in groups.values()]
    runs = groups[scored[0][1]]
    print(f"\n== {fam}: {len(groups)} variants")
    print(f" SELECTED {scored[0][1]}")
    if len(runs) == 1:
        print(f"  train : {line(runs[0], 'train')}")
        print(f"  target: {line(runs[0], 'target')}")
    else:
        print(f"  train  mean return {fmean(x['train']['return'] for x in runs):.2f}  seeds {[x['train']['return'] for x in runs]}")
        print(f"  target mean return {fmean(x['target']['return'] for x in runs):.2f}  seeds {[x['target']['return'] for x in runs]}")
    print(f"  all variants train:  median {median(all_train):.2f}  positive {sum(x > 0 for x in all_train)}/{len(all_train)}")
    print(f"  all variants target: median {median(all_target):.2f}  positive {sum(x > 0 for x in all_target)}/{len(all_target)}  best {max(all_target):.2f}  worst {min(all_target):.2f}")
    by_cls = defaultdict(list)
    for id_, runs2 in groups.items():
        by_cls[id_.split("(")[0]].append((fmean(x["train"]["return"] for x in runs2), fmean(x["target"]["return"] for x in runs2)))
    for c, v in by_cls.items():
        print(f"   {c}: n={len(v)} median train {median(a for a, _ in v):.2f} median target {median(b for _, b in v):.2f} target positive {sum(b > 0 for _, b in v)}/{len(v)}")
    print("  top 3 by train Sharpe:")
    for s, id_ in scored[:3]:
        print(f"   {s:.2f} {id_} target={fmean(x['target']['return'] for x in groups[id_]):.2f}")
json.dump(selected, open("data/research_selected.json", "w"), indent=1)
