"""Builds longer candles from 1-minute bars, so a strategy only runs when its candle closes."""
from __future__ import annotations

from collections import defaultdict

from ..data.session import ET
from ..models import Bar, Signal
from .base import BaseBot

SESSION_MINUTES = 390
MAX_CANDLES = 300


class TimeframeBot(BaseBot):
    def __init__(self, risk=None, tf=SESSION_MINUTES, base_minutes=1):
        super().__init__(risk)
        self.tf = tf
        self.base = base_minutes
        self.candles: dict[str, list[Bar]] = defaultdict(list)
        self._open: dict[str, tuple[tuple, Bar]] = {}

    def on_candle(self, ticker: str, candles: list[Bar]) -> Signal | None:
        raise NotImplementedError

    def signal(self, ticker, bars):
        bar = bars[-1]
        local = bar.ts.astimezone(ET)
        offset = local.hour * 60 + local.minute - 570
        slot = (local.date(), offset // self.tf)
        result = None

        # The live feed can miss a candle's last minute. Close it late rather than lose it.
        pending = self._open.get(ticker)
        if pending and pending[0] != slot:
            result = self._close(ticker, pending[1])
            pending = None

        merged = bar if pending is None else Bar(
            ticker, pending[1].ts, pending[1].open, max(pending[1].high, bar.high),
            min(pending[1].low, bar.low), bar.close, pending[1].volume + bar.volume,
        )
        ends_slot = offset + self.base >= (offset // self.tf + 1) * self.tf
        if ends_slot or offset + self.base >= SESSION_MINUTES:
            return self._close(ticker, merged) or result
        self._open[ticker] = (slot, merged)
        return result

    def _close(self, ticker, candle):
        self._open.pop(ticker, None)
        candles = self.candles[ticker]
        candles.append(candle)
        del candles[:-MAX_CANDLES]
        return self.on_candle(ticker, candles)
