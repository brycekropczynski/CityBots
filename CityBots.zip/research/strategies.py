"""Every candidate from the strategy search, frozen as tested so results stay reproducible.

The simulator's own bots live in citybots/bots/.
"""
from __future__ import annotations

import random
from collections import defaultdict
from statistics import fmean, pstdev

from citybots.bots.base import BaseBot
from citybots.bots.inverse_fvg import GapTracker
from citybots.data.session import ET
from citybots.models import Bar, Side, Signal

SESSION_MINUTES = 390
BUY, SELL = Side.BUY, Side.SELL


class TimeframeBot(BaseBot):
    """Builds longer candles from incoming bars. Strategies run only when a candle closes."""

    def __init__(self, risk=None, tf=60, base_minutes=1):
        super().__init__(risk)
        self.tf = tf
        self.base = base_minutes
        self.candles: dict[str, list[Bar]] = defaultdict(list)
        self.daily: dict[str, list[float]] = defaultdict(list)
        self.day_count = 0
        self._open: dict[str, Bar] = {}

    def signal(self, ticker, bars):
        bar = bars[-1]
        local = bar.ts.astimezone(ET)
        offset = local.hour * 60 + local.minute - 570
        day_over = offset + self.base >= SESSION_MINUTES
        if day_over:
            self.daily[ticker].append(bar.close)
            del self.daily[ticker][:-260]
            if ticker == "SPY":
                self.day_count += 1
        p = self._open.get(ticker)
        merged = bar if p is None else Bar(ticker, p.ts, p.open, max(p.high, bar.high), min(p.low, bar.low),
                                           bar.close, p.volume + bar.volume)
        if offset + self.base < (offset // self.tf + 1) * self.tf and not day_over:
            self._open[ticker] = merged
            return None
        self._open.pop(ticker, None)
        candles = self.candles[ticker]
        candles.append(merged)
        del candles[:-300]
        return self.on_candle(ticker, candles, offset, day_over)

    def on_candle(self, ticker, candles, offset, day_over):
        raise NotImplementedError

    def above_sma(self, ticker, n):
        closes = self.daily[ticker]
        return len(closes) >= n and closes[-1] > fmean(closes[-n:])

    def regime(self, n):
        return not n or self.above_sma("SPY", n)


class Donchian(TimeframeBot):
    """Trend following: buy a breakout above the N-candle high, exit below the M-candle low."""
    def __init__(self, risk=None, tf=390, base_minutes=1, entry=20, exit=10, regime=0):
        super().__init__(risk, tf, base_minutes)
        self.entry, self.exit, self.regime_n = entry, exit, regime

    def on_candle(self, t, c, offset, day_over):
        if len(c) <= self.entry:
            return None
        last, prior = c[-1], c[-self.entry - 1:-1]
        if last.close < min(b.low for b in prior[-self.exit:]):
            return Signal(SELL, "trend exit")
        if last.close > max(b.high for b in prior) and self.regime(self.regime_n):
            return Signal(BUY, "breakout")
        return None


class Rotation(TimeframeBot):
    """Every k days, hold the top N tickers by trailing return; sits in cash in a weak market."""
    def __init__(self, risk=None, base_minutes=1, lookback=20, top=5, every=5, regime=50):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.lookback, self.top, self.every, self.regime_n = lookback, top, every, regime

    def on_candle(self, t, c, offset, day_over):
        if self.day_count % self.every:
            return None
        # Uses the previous close for every ticker, so processing order can't leak information.
        scores = {k: v[-2] / v[-2 - self.lookback] for k, v in self.daily.items() if len(v) >= self.lookback + 2}
        if t not in scores:
            return None
        best = sorted(scores, key=scores.get, reverse=True)[:self.top]
        if t in best and scores[t] > 1 and self.regime(self.regime_n):
            return Signal(BUY, "top momentum")
        return Signal(SELL, "dropped from top")


class OpeningRange(TimeframeBot):
    """Buy a break of the opening range; always flat by the close, so no overnight risk."""
    def __init__(self, risk=None, base_minutes=1, minutes=30, regime=0):
        super().__init__(risk, 5, base_minutes)
        self.minutes, self.regime_n = minutes, regime
        self.high = {}

    def on_candle(self, t, c, offset, day_over):
        bucket = offset // 5 * 5
        if bucket >= 380:
            return Signal(SELL, "end of day")
        if bucket < self.minutes:
            self.high[t] = max(self.high.get(t, 0.0) if bucket else 0.0, c[-1].high)
            self.traded = getattr(self, "traded", {})
            self.traded[t] = False
            return None
        if bucket < 300 and not self.traded[t] and c[-1].close > self.high[t] and self.regime(self.regime_n):
            self.traded[t] = True
            return Signal(BUY, "opening range break")
        return None


class Bands(TimeframeBot):
    """The original 20-period reversion idea on slower candles, with an optional trend filter."""
    def __init__(self, risk=None, tf=390, base_minutes=1, period=20, entry_std=2.0, trend=0):
        super().__init__(risk, tf, base_minutes)
        self.period, self.entry_std, self.trend = period, entry_std, trend

    def on_candle(self, t, c, offset, day_over):
        if len(c) < self.period:
            return None
        closes = [b.close for b in c[-self.period:]]
        mean, std = fmean(closes), pstdev(closes)
        if closes[-1] >= mean:
            return Signal(SELL, "back at average")
        if closes[-1] < mean - self.entry_std * std and (not self.trend or self.above_sma(t, self.trend)):
            return Signal(BUY, "stretched below average")
        return None


class RSI2(TimeframeBot):
    """Buy a sharp daily pullback inside an uptrend; exit on the first bounce above the 5-day average."""
    def __init__(self, risk=None, base_minutes=1, entry=10, trend=100):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.entry, self.trend = entry, trend

    def on_candle(self, t, c, offset, day_over):
        closes = [b.close for b in c[-30:]]
        if len(closes) < 30:
            return None
        up = down = 0.0
        for i, (a, b) in enumerate(zip(closes, closes[1:])):
            gain, loss = max(b - a, 0), max(a - b, 0)
            up, down = (gain, loss) if i == 0 else ((up + gain) / 2, (down + loss) / 2)
        rsi = 100.0 if down == 0 else 100 - 100 / (1 + up / down)
        if closes[-1] > fmean(closes[-5:]):
            return Signal(SELL, "bounce")
        if rsi < self.entry and (not self.trend or self.above_sma(t, self.trend)):
            return Signal(BUY, "RSI(2) pullback")
        return None


class SlowIFVG(TimeframeBot):
    """Inverse fair value gaps on slower candles, with bigger gaps and an optional trend filter."""
    def __init__(self, risk=None, tf=60, base_minutes=1, min_gap=0.002, trend=0, max_hold=0, max_age=40):
        super().__init__(risk, tf, base_minutes)
        self.core = GapTracker(min_gap, max_age)
        self.trend, self.max_hold = trend, max_hold
        self.held = defaultdict(int)

    def on_candle(self, t, c, offset, day_over):
        self.held[t] = self.held[t] + 1 if t in self.positions else 0
        sig = self.core.update(t, c)
        if self.max_hold and self.held[t] >= self.max_hold:
            return Signal(SELL, "max hold")
        if sig and sig.side is BUY and self.trend and not self.above_sma(t, self.trend):
            return None
        return sig


class RandomHold(TimeframeBot):
    """Random entries with long holds. Tests what patience alone is worth, with no signal."""
    def __init__(self, risk=None, base_minutes=1, prob=0.05, hold=20, seed=42):
        super().__init__(risk, SESSION_MINUTES, base_minutes)
        self.rng = random.Random(seed)
        self.prob, self.hold = prob, hold
        self.held = defaultdict(int)

    def on_candle(self, t, c, offset, day_over):
        roll = self.rng.random()
        if t in self.positions:
            self.held[t] += 1
            return Signal(SELL, "hold over") if self.held[t] >= self.hold else None
        self.held[t] = 0
        return Signal(BUY, "coin flip") if roll < self.prob else None
