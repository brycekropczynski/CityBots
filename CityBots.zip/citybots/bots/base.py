"""BaseBot owns the money: cash, positions, sizing and stop-losses.

Subclasses only implement signal(), so every strategy follows identical risk rules.
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from collections.abc import Sequence

from ..config import RiskConfig
from ..models import Bar, Decision, Fill, Position, Side, Signal

HISTORY_BARS = 200
CASH_BUFFER = 0.995  # room for the fill to land slightly above the price used for sizing
DUST = 1e-6


class BaseBot(ABC):
    name = "base"

    def __init__(self, risk: RiskConfig | None = None):
        self.risk = risk or RiskConfig()
        self.cash = self.risk.starting_cash
        self.positions: dict[str, Position] = {}
        self.marks: dict[str, float] = {}
        self.history: dict[str, deque[Bar]] = defaultdict(lambda: deque(maxlen=HISTORY_BARS))
        self.trade_count = 0
        self.realized_pnl = 0.0
        self._reserved = 0.0
        self._bars_seen: dict[str, int] = defaultdict(int)
        self._cooldown_until: dict[str, int] = {}

    @abstractmethod
    def signal(self, ticker: str, bars: Sequence[Bar]) -> Signal | None:
        """Called exactly once per closed bar, whether or not the bot holds the ticker."""

    # --- Valuation -------------------------------------------------------------------
    @property
    def equity(self) -> float:
        return self.cash + sum(
            p.qty * self.marks.get(t, p.avg_price) for t, p in self.positions.items()
        )

    @property
    def return_pct(self) -> float:
        return (self.equity / self.risk.starting_cash - 1) * 100

    def update_marks(self, prices: dict[str, float]) -> None:
        self.marks.update(prices)

    # --- Decisions -------------------------------------------------------------------
    def begin_round(self) -> None:
        self._reserved = 0.0

    def check_stops(self, lows: dict[str, float]) -> list[Decision]:
        return [
            Decision(self.name, t, Side.SELL, p.qty, "stop-loss", stop_price=p.stop_price)
            for t, p in self.positions.items()
            if t in lows and lows[t] <= p.stop_price
        ]

    def warm_up(self, bar: Bar) -> None:
        """Feed pre-start history so strategies have context; never produces a trade."""
        self.history[bar.ticker].append(bar)
        self._bars_seen[bar.ticker] += 1
        self.marks[bar.ticker] = bar.close
        self.signal(bar.ticker, self.history[bar.ticker])

    def on_bar(self, bar: Bar) -> Decision | None:
        t = bar.ticker
        self.history[t].append(bar)
        self._bars_seen[t] += 1
        self.marks[t] = bar.close
        sig = self.signal(t, self.history[t])
        if sig is None:
            return None
        held = self.positions.get(t)
        if sig.side is Side.SELL:
            return Decision(self.name, t, Side.SELL, held.qty, sig.reason) if held else None
        if held or self._bars_seen[t] <= self._cooldown_until.get(t, 0):
            return None
        qty = self._size_buy(bar.close)
        return Decision(self.name, t, Side.BUY, qty, sig.reason) if qty else None

    def _size_buy(self, price: float) -> float:
        free_cash = self.cash - self._reserved
        notional = CASH_BUFFER * min(self.risk.max_position_pct * self.equity, free_cash)
        if notional < self.risk.min_order_notional or price <= 0:
            return 0.0
        qty = math.floor(notional / price * 10_000) / 10_000
        self._reserved += qty * price
        return qty

    # --- Ledger ----------------------------------------------------------------------
    def apply_fill(self, fill: Fill) -> None:
        t = fill.ticker
        if fill.side is Side.BUY:
            self.cash -= fill.qty * fill.price
            held = self.positions.get(t)
            qty = fill.qty + (held.qty if held else 0.0)
            cost = fill.qty * fill.price + (held.qty * held.avg_price if held else 0.0)
            avg = cost / qty
            self.positions[t] = Position(qty, avg, avg * (1 - self.risk.stop_loss_pct))
        else:
            held = self.positions.get(t)
            if held is None:
                return
            qty = min(fill.qty, held.qty)
            fill.qty = qty
            self.cash += qty * fill.price
            fill.realized_pnl = qty * (fill.price - held.avg_price)
            self.realized_pnl += fill.realized_pnl
            held.qty -= qty
            if held.qty <= DUST:
                del self.positions[t]
            if fill.reason == "stop-loss":
                self._cooldown_until[t] = self._bars_seen[t] + self.risk.reentry_cooldown_bars
        self.trade_count += 1
        self.marks.setdefault(t, fill.price)

    def restore(self, trades) -> None:
        """Rebuild the ledger from logged trades after a restart."""
        from datetime import datetime

        for row in trades:
            self.apply_fill(Fill(
                row["bot"], row["ticker"], Side(row["side"]), row["qty"], row["price"],
                datetime.fromisoformat(row["time"]), row["reason"] or "", row["order_id"] or "",
            ))
