"""Is the Random bot's 4-year result luck? Also runs each position size through falling 2022."""
import asyncio
import multiprocessing as mp
from collections import defaultdict
from dataclasses import replace
from datetime import date, timedelta
from statistics import fmean, median

from citybots.bots import InverseFVGBot, MeanReversionBot, MomentumBot, RandomBot
from citybots.config import RiskConfig, load_settings
from citybots.data.replay_feed import load_alpaca_bars
from citybots.data.session import ET
from citybots.engine import Engine
from citybots.execution.sim_broker import SimBroker
from citybots.hub import Hub
from citybots.models import Bar

from .harness import NullStore, WarmReplay
from .prepare_data import bucket

WINDOWS = {}
SIZES = [0.10, 0.20, 0.33, 0.50, 1.00]


def to_5m(bars):
    groups = defaultdict(list)
    for b in bars:
        groups[(b.ticker, bucket(b.ts))].append(b)
    out = []
    for (t, ts), g in groups.items():
        g.sort(key=lambda b: b.ts)
        out.append(Bar(t, ts, g[0].open, max(b.high for b in g), min(b.low for b in g), g[-1].close, sum(b.volume for b in g)))
    out.sort(key=lambda b: (b.ts, b.ticker))
    return out


def job(j):
    cls = globals()[j["cls"]]
    risk = replace(RiskConfig(), stop_loss_pct=cls.default_stop, max_position_pct=j["size"])
    bot = RandomBot(risk, base_minutes=5, seed=j["seed"]) if cls is RandomBot else cls(risk, base_minutes=5)
    store, hub = NullStore(), Hub()
    warm, live = WINDOWS[j["win"]]
    asyncio.run(Engine([bot], WarmReplay(live, warm), SimBroker(2.0), store, hub, "r", "replay").run())
    assert hub.status["state"] == "finished", hub.status
    eq = [v[0] for _, v in sorted(store.daily.items())]
    peak, dd = eq[0], 0.0
    for e in eq:
        peak = max(peak, e)
        dd = min(dd, e / peak - 1)
    return j, bot.return_pct, dd * 100


def main():
    s = load_settings()
    a = to_5m(load_alpaca_bars(s, date(2022, 9, 4), date(2022, 11, 2)))
    b = to_5m(load_alpaca_bars(s, date(2022, 11, 3), date(2026, 11, 3)))
    WINDOWS["4yr"] = (a, b)
    old = to_5m(load_alpaca_bars(s, date(2021, 8, 30), date(2022, 12, 30)))
    start = date(2022, 1, 3)
    WINDOWS["2022"] = ([x for x in old if x.ts.astimezone(ET).date() < start and x.ts.astimezone(ET).date() >= start - timedelta(days=60)],
                       [x for x in old if x.ts.astimezone(ET).date() >= start])
    jobs = [{"cls": "RandomBot", "size": z, "seed": 100 + i, "win": "4yr"} for z in (0.10, 0.33, 0.50) for i in range(30)]
    jobs += [{"cls": c, "size": z, "seed": 42, "win": "2022"} for c in ("MomentumBot", "MeanReversionBot", "InverseFVGBot") for z in SIZES]
    jobs += [{"cls": "RandomBot", "size": z, "seed": 100 + i, "win": "2022"} for z in SIZES for i in range(30)]
    res = defaultdict(list)
    with mp.get_context("fork").Pool(6) as pool:
        for j, r, dd in pool.imap_unordered(job, jobs):
            res[(j["win"], j["cls"], j["size"])].append((r, dd))
    for k in sorted(res):
        v = res[k]
        rr = [x[0] for x in v]
        if len(v) == 1:
            print(k, f"return {rr[0]:.2f} dd {v[0][1]:.2f}")
        else:
            print(k, f"seeds {len(v)} median {median(rr):.2f} mean {fmean(rr):.2f} min {min(rr):.2f} max {max(rr):.2f} median dd {median(x[1] for x in v):.2f} positive {sum(x > 0 for x in rr)}")


if __name__ == "__main__":
    main()
