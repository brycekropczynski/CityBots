"""Download 1-minute bars (cached) and compress them to 5-minute bars for fast research runs."""
import pickle
import time
from collections import defaultdict
from datetime import date, timedelta

from citybots.config import load_settings
from citybots.data.replay_feed import load_alpaca_bars
from citybots.data.session import ET
from citybots.models import Bar

OUT = "data/cache/research_5m.pkl"
RANGES = [(date(2025, 1, 2), date(2026, 5, 2)), (date(2026, 5, 3), date(2026, 11, 3))]


def bucket(ts):
    local = ts.astimezone(ET)
    offset = (local.hour * 60 + local.minute - 570) // 5 * 5
    return ts - timedelta(minutes=(local.hour * 60 + local.minute - 570) - offset)


def main():
    settings = load_settings()
    out = []
    for start, end in RANGES:
        t = time.time()
        bars = load_alpaca_bars(settings, start, end)
        print(start, end, len(bars), "bars", round(time.time() - t), "s", flush=True)
        groups = defaultdict(list)
        for b in bars:
            groups[(b.ticker, bucket(b.ts))].append(b)
        for (ticker, ts), g in groups.items():
            g.sort(key=lambda b: b.ts)
            out.append(Bar(ticker, ts, g[0].open, max(b.high for b in g), min(b.low for b in g),
                           g[-1].close, sum(b.volume for b in g)))
        del bars, groups
    out.sort(key=lambda b: (b.ts, b.ticker))
    with open(OUT, "wb") as f:
        pickle.dump(out, f, protocol=pickle.HIGHEST_PROTOCOL)
    print("5-minute bars:", len(out), out[0].ts, out[-1].ts)


if __name__ == "__main__":
    main()
