"""Builds the 4-year bar cache from months already cached, fetching only what's missing."""
import glob
import hashlib
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta

from citybots.config import load_settings
from citybots.data.replay_feed import _read_cache, _write_cache, load_alpaca_bars
from citybots.data.session import ET

START, END = date(2022, 11, 3), date(2026, 11, 3)
GAP = (date(2022, 12, 31), date(2024, 11, 2))
HAVE = [(date(2021, 8, 30), date(2022, 12, 30)), (date(2024, 11, 3), date(2026, 11, 3))]


def chunks():
    a = GAP[0]
    while a <= GAP[1]:
        next_month = (a.replace(day=1) + timedelta(days=32)).replace(day=1)
        b = min(next_month - timedelta(days=1), GAP[1])
        yield a, b
        a = b + timedelta(days=1)


def main():
    s = load_settings()
    t0 = time.time()
    parts = list(chunks())
    results = {}
    with ThreadPoolExecutor(4) as pool:
        futures = {pool.submit(load_alpaca_bars, s, a, b): (a, b) for a, b in parts}
        for i, f in enumerate(as_completed(futures), 1):
            results[futures[f]] = len(f.result())
            print(f"{i}/{len(parts)} months {futures[f][0]} {results[futures[f]]} bars {round(time.time() - t0)}s", flush=True)
    bars = []
    for a, b in parts + HAVE:
        for bar in load_alpaca_bars(s, a, b):
            if START <= bar.ts.astimezone(ET).date() <= END:
                bars.append(bar)
    key = hashlib.sha256(",".join(sorted(s.tickers)).encode()).hexdigest()[:10]
    path = os.path.join(s.cache_dir, f"bars_{START}_{END}_{key}.csv.gz")
    _write_cache(path, bars)
    print("merged", len(bars), "bars", round(time.time() - t0), "s", flush=True)


if __name__ == "__main__":
    main()
